#!/usr/bin/env node
/**
 * Builds public/GRIDWATCH_ICS.xlsx — 5-sheet SOC/OT workbook.
 */
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import ExcelJS from "exceljs";

const OUT = "/workspace/public/GRIDWATCH_ICS.xlsx";

const C = {
  ink: "FF0C1014",
  surface: "FF141A21",
  surface2: "FF1B232C",
  card: "FF1E2832",
  fg: "FFE8EDF2",
  muted: "FF8B98A5",
  subtle: "FF6B7884",
  line: "FF2A343E",
  steel: "FFC5CCD4",
  crit: "FFE11D48",
  critBg: "FF3A1520",
  high: "FFD97706",
  highBg: "FF3A2A12",
  ok: "FF0F9D7A",
  okBg: "FF0F2A24",
  warn: "FFD97706",
  warnBg: "FF33240E",
  info: "FF5B8FB3",
  infoBg: "FF152030",
  white: "FFFFFFFF",
  banner: "FF080C10",
  p0: "FFE11D48",
  p1: "FFD97706",
  p2: "FF5B8FB3",
};

const EVENTS = [
  ["EVT-001", "2026-10-01 02:14:00", "200.1.8.45", "200.1.8.0/24", "198.51.100.22", "C2 externo", "Beaconing C2", "10.4806,-66.9036 (Caracas)", "Alta", "Explotacion EMS", "365ede59ae5b9332b9fb...", "FAM-EMS-C2", "Bloqueado", "1. Comando y control", "ICS T0885 / T0869", "Baliza C2 bloqueada en el perímetro. No hubo sesión establecida."],
  ["EVT-002", "2026-10-01 02:18:12", "200.1.9.112", "200.1.9.0/24", "10.0.50.5", "OT LAN", "Movimiento Lateral", "10.4806,-66.9036 (Caracas)", "Critica", "Pivote IT a OT", "77f2209a3a35b879ffdd...", "FAM-PIVOTE", "Exitoso", "2. Cruce de air-gap lógico", "ICS T0866 / T0886", "El atacante cruzó de la red IT al LAN OT. Punto de no retorno operativo."],
  ["EVT-003", "2026-10-01 02:25:30", "200.1.10.14", "200.1.10.0/24", "10.0.50.12", "RTU", "Inyeccion de Paquetes ICS", "10.4806,-66.9036 (Caracas)", "Critica", "Manipulacion Protocolo DNP3", "65b928be07f528ded928...", "FAM-ICS-PAYLOAD", "Exitoso", "3. Manipulación de control", "ICS T0831 / T0836", "Paquetes DNP3 inyectados a una RTU. Posible alteración de telemetría o consigna."],
  ["EVT-004", "2026-10-02 14:05:22", "200.1.11.250", "200.1.11.0/24", "198.51.100.44", "Exfil C2", "Exfiltracion de Datos", "10.4806,-66.9036 (Caracas)", "Alta", "Robo de Credenciales", "77f2209a3a35b879ffdd...", "FAM-PIVOTE", "Investigando", "4. Exfiltración", "ICS T0893 / T0882", "Salida de datos hacia 198.51.100.44. Alcance de lo robado aún no cerrado."],
  ["EVT-005", "2026-10-02 18:40:00", "200.1.12.8", "200.1.12.0/24", "10.0.60.2", "HMI", "Despliegue de Malware", "10.4806,-66.9036 (Caracas)", "Critica", "Wiper (Borrado de Configuración)", "65b928be07f528ded928...", "FAM-ICS-PAYLOAD", "Exitoso", "5. Impacto / destrucción", "ICS T0826 / T0872", "Wiper en HMI. Pérdida de configuración de supervisión. Recuperar desde backup limpio."],
  ["EVT-006", "2026-10-03 04:10:15", "200.1.8.201", "200.1.8.0/24", "198.51.100.22", "C2 externo", "Beaconing C2", "10.4806,-66.9036 (Caracas)", "Alta", "Explotacion EMS", "365ede59ae5b9332b9fb...", "FAM-EMS-C2", "Bloqueado", "1. Comando y control", "ICS T0885 / T0869", "Segunda baliza al mismo C2, bloqueada. El actor reintenta el canal EMS."],
  ["EVT-007", "2026-10-03 09:22:45", "200.1.11.55", "200.1.11.0/24", "10.0.50.15", "PLC", "Intento de Modificacion", "10.4806,-66.9036 (Caracas)", "Critica", "Sobrescritura de Firmware", "65b928be07f528ded928...", "FAM-ICS-PAYLOAD", "Bloqueado", "6. Persistencia en campo", "ICS T0857", "Intento de reflash de PLC detenido. Si hubiera pasado, el control quedaba en manos del actor."],
];

const HEADERS = [
  "ID", "Fecha_Hora", "IP_Origen", "Segmento", "IP_Destino", "Activo",
  "Tipo_Evento", "Coordenadas_Aprox", "Severidad", "Metodo_Ataque",
  "Hash_Asociado", "Familia", "Estado", "Fase", "MITRE ICS", "Impacto",
];

function font(size, opts = {}) {
  return {
    name: opts.mono ? "Consolas" : "Calibri",
    size,
    bold: !!opts.bold,
    italic: !!opts.italic,
    color: { argb: opts.color || C.fg },
  };
}

function fill(argb) {
  return { type: "pattern", pattern: "solid", fgColor: { argb } };
}

function thin(argb = C.line) {
  const s = { style: "thin", color: { argb } };
  return { top: s, left: s, bottom: s, right: s };
}

function align(h = "left", v = "middle", wrap = true) {
  return { horizontal: h, vertical: v, wrapText: wrap };
}

function paint(ws, range, argb) {
  const [a, b] = range.split(":");
  const s = cellAddr(a);
  const e = cellAddr(b || a);
  for (let r = s.r; r <= e.r; r++) {
    for (let c = s.c; c <= e.c; c++) {
      ws.getCell(r, c).fill = fill(argb);
    }
  }
}

function cellAddr(a) {
  const m = String(a).match(/^([A-Z]+)(\d+)$/);
  const letters = m[1];
  let c = 0;
  for (let i = 0; i < letters.length; i++) c = c * 26 + (letters.charCodeAt(i) - 64);
  return { r: Number(m[2]), c };
}

function styleCell(cell, { fillArgb, font: f, alignment, border, numFmt } = {}) {
  if (fillArgb) cell.fill = fill(fillArgb);
  if (f) cell.font = f;
  if (alignment) cell.alignment = alignment;
  if (border) cell.border = border;
  if (numFmt) cell.numFmt = numFmt;
}

function mergeVal(ws, range, value, spec) {
  ws.mergeCells(range);
  const cell = ws.getCell(range.split(":")[0]);
  cell.value = value;
  styleCell(cell, spec);
  return cell;
}

function sevFill(s) {
  return s === "Critica" ? C.critBg : C.highBg;
}
function sevFg(s) {
  return s === "Critica" ? C.crit : C.high;
}
function estFill(s) {
  if (s === "Bloqueado") return C.okBg;
  if (s === "Exitoso") return C.critBg;
  return C.warnBg;
}
function estFg(s) {
  if (s === "Bloqueado") return C.ok;
  if (s === "Exitoso") return C.crit;
  return C.warn;
}

function bars(n, max, ch = "█") {
  const w = 16;
  const filled = Math.max(1, Math.round((n / max) * w));
  return ch.repeat(filled) + "░".repeat(Math.max(0, w - filled));
}

function setupSheet(ws, { tab, landscape = true, fitH = 1 }) {
  ws.properties.tabColor = { argb: tab };
  ws.views = [{ showGridLines: false, zoomScale: 90, state: "normal" }];
  ws.pageSetup = {
    paperSize: 9,
    orientation: landscape ? "landscape" : "portrait",
    fitToPage: true,
    fitToWidth: 1,
    fitToHeight: fitH,
    margins: { left: 0.35, right: 0.35, top: 0.45, bottom: 0.45, header: 0.2, footer: 0.2 },
    printTitlesRow: "1:4",
  };
  ws.headerFooter = {
    oddHeader: "&LGRIDWATCH ICS/OT&CCorpoelec · Electricidad de Caracas&R1–3 oct 2026",
    oddFooter: "&LCONFIDENCIAL · Uso interno SOC/OT&CPágina &P de &N&RNo distribuir",
  };
}

function fillSheet(ws, rows, cols, argb) {
  for (let r = 1; r <= rows; r++) {
    const row = ws.getRow(r);
    for (let c = 1; c <= cols; c++) {
      const cell = row.getCell(c);
      if (!cell.fill || cell.fill.fgColor?.argb == null) {
        cell.fill = fill(argb);
      }
    }
  }
}

async function build() {
  const wb = new ExcelJS.Workbook();
  wb.creator = "GRIDWATCH SOC";
  wb.lastModifiedBy = "GRIDWATCH";
  wb.created = new Date("2026-10-05T18:00:00Z");
  wb.modified = new Date();
  wb.company = "Corpoelec · Electricidad de Caracas";
  wb.title = "GRIDWATCH — Incidentes ICS/OT Caracas 1–3 oct 2026";
  wb.subject = "Campaña contra EMS / OT LAN / RTU / HMI / PLC";
  wb.description = "Tablero de incidentes ciberfísicos. 7 eventos, 3 familias, ventana de 55 h.";
  wb.keywords = "ICS,OT,DNP3,EMS,Corpoelec,Caracas,SOC";
  wb.category = "Informe de incidentes";

  buildDashboard(wb);
  buildEventos(wb);
  buildCadena(wb);
  buildAnalisis(wb);
  buildGlosario(wb);

  mkdirSync(dirname(OUT), { recursive: true });
  await wb.xlsx.writeFile(OUT);
  console.log("Wrote", OUT);
}

function buildDashboard(wb) {
  const ws = wb.addWorksheet("01 Dashboard", { properties: { defaultRowHeight: 16 } });
  setupSheet(ws, { tab: C.steel, fitH: 2 });

  const colW = [3, 14, 14, 14, 14, 14, 14, 16, 16, 14, 14, 16, 16, 14, 14, 3];
  colW.forEach((w, i) => { ws.getColumn(i + 1).width = w; });

  paint(ws, "A1:P4", C.banner);
  mergeVal(ws, "B2:I2", "GRIDWATCH", {
    font: font(22, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  mergeVal(ws, "J2:O2", "CONFIDENCIAL", {
    font: font(11, { bold: true, color: C.crit }),
    alignment: align("right", "middle", false),
  });
  mergeVal(
    ws,
    "B3:O3",
    "Centro de operaciones ICS/OT  ·  Corpoelec / Electricidad de Caracas  ·  10.4806, −66.9036  ·  1–3 octubre 2026",
    { font: font(11, { color: C.muted }), alignment: align("left", "middle", false) },
  );
  mergeVal(
    ws,
    "B4:O4",
    "Campaña coordinada contra EMS, LAN OT, RTU, HMI y PLC. Tres familias de hash. Contención 43 %. Compromiso OT confirmado.",
    { font: font(10, { italic: true, color: C.subtle }), alignment: align("left", "middle", false) },
  );
  ws.getRow(2).height = 28;
  ws.getRow(3).height = 18;
  ws.getRow(4).height = 18;

  const kpis = [
    { range: "B6:C8", value: 7, label: "EVENTOS", sub: "en 55 h 08 min", fg: C.steel },
    { range: "D6:E8", value: 4, label: "CRÍTICOS", sub: "tocan activos OT", fg: C.crit },
    { range: "F6:G8", value: 3, label: "EXITOSOS", sub: "el acto ocurrió", fg: C.crit },
    { range: "H6:I8", value: 3, label: "BLOQUEADOS", sub: "contenidos a tiempo", fg: C.ok },
    { range: "J6:K8", value: "43%", label: "CONTENCIÓN", sub: "3 de 7 detenidos", fg: C.high },
    { range: "L6:M8", value: 3, label: "FAMILIAS", sub: "hashes únicos", fg: C.info },
    { range: "N6:O8", value: 6, label: "SEGMENTOS", sub: "IT 200.1.8–12/24", fg: C.steel },
  ];
  for (const k of kpis) {
    paint(ws, k.range, C.card);
    const [a, b] = k.range.split(":");
    const start = ws.getCell(a);
    // border around merged block
    const s = cellAddr(a);
    const e = cellAddr(b);
    for (let r = s.r; r <= e.r; r++) {
      for (let c = s.c; c <= e.c; c++) {
        const cell = ws.getCell(r, c);
        cell.fill = fill(C.card);
        cell.border = thin(C.line);
      }
    }
    mergeVal(ws, `${colLetter(s.c)}${s.r}:${colLetter(e.c)}${s.r}`, k.label, {
      font: font(8, { bold: true, color: C.muted }),
      alignment: align("left", "bottom", false),
    });
    mergeVal(ws, `${colLetter(s.c)}${s.r + 1}:${colLetter(e.c)}${s.r + 1}`, k.value, {
      font: font(22, { bold: true, color: k.fg }),
      alignment: align("left", "middle", false),
    });
    mergeVal(ws, `${colLetter(s.c)}${s.r + 2}:${colLetter(e.c)}${s.r + 2}`, k.sub, {
      font: font(8, { color: C.subtle }),
      alignment: align("left", "top", false),
    });
  }
  ws.getRow(6).height = 16;
  ws.getRow(7).height = 28;
  ws.getRow(8).height = 16;

  // Section titles
  mergeVal(ws, "B10:G10", "SEVERIDAD Y ESTADO", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  mergeVal(ws, "I10:O10", "TIPOS DE EVENTO", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });

  const sevRows = [
    ["Crítica", 4, "57%", "RTU, PLC, HMI, OT LAN"],
    ["Alta", 3, "43%", "C2 / EMS / exfiltración"],
  ];
  ["Nivel", "N", "%", "Qué implica"].forEach((h, i) => {
    const cell = ws.getCell(11, 2 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  sevRows.forEach((row, i) => {
    row.forEach((val, j) => {
      const cell = ws.getCell(12 + i, 2 + j);
      cell.value = val;
      const fg = row[0] === "Crítica" ? C.crit : C.high;
      const bg = row[0] === "Crítica" ? C.critBg : C.highBg;
      styleCell(cell, {
        fillArgb: j === 0 ? bg : C.surface,
        font: font(10, { bold: j === 0, color: j === 0 ? fg : C.fg, mono: j === 1 || j === 2 }),
        alignment: align("left", "middle", false),
        border: thin(),
      });
    });
  });

  const estRows = [
    ["Exitoso", 3, "43%", "El acto se ejecutó"],
    ["Bloqueado", 3, "43%", "Control lo detuvo"],
    ["Investigando", 1, "14%", "Exfil aún abierta"],
  ];
  ["Estado", "N", "%", "Lectura"].forEach((h, i) => {
    const cell = ws.getCell(15, 2 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  estRows.forEach((row, i) => {
    row.forEach((val, j) => {
      const cell = ws.getCell(16 + i, 2 + j);
      cell.value = val;
      styleCell(cell, {
        fillArgb: j === 0 ? estFill(row[0]) : C.surface,
        font: font(10, { bold: j === 0, color: j === 0 ? estFg(row[0]) : C.fg, mono: j === 1 || j === 2 }),
        alignment: align("left", "middle", false),
        border: thin(),
      });
    });
  });

  const tipos = [
    ["Beaconing C2", 2],
    ["Movimiento Lateral", 1],
    ["Inyeccion de Paquetes ICS", 1],
    ["Exfiltracion de Datos", 1],
    ["Despliegue de Malware", 1],
    ["Intento de Modificacion", 1],
  ];
  ["Tipo", "N", "Distribución"].forEach((h, i) => {
    const cell = ws.getCell(11, 9 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  ws.mergeCells("K11:O11");
  tipos.forEach((row, i) => {
    const r = 12 + i;
    ws.getCell(r, 9).value = row[0];
    styleCell(ws.getCell(r, 9), { fillArgb: C.surface, font: font(10, { color: C.fg }), alignment: align("left", "middle", false), border: thin() });
    ws.getCell(r, 10).value = row[1];
    styleCell(ws.getCell(r, 10), { fillArgb: C.surface, font: font(10, { bold: true, color: C.steel, mono: true }), alignment: align("center", "middle", false), border: thin() });
    ws.mergeCells(r, 11, r, 15);
    ws.getCell(r, 11).value = bars(row[1], 2);
    styleCell(ws.getCell(r, 11), {
      fillArgb: C.surface,
      font: font(9, { color: row[0].includes("C2") ? C.high : C.crit, mono: true }),
      alignment: align("left", "middle", false),
      border: thin(),
    });
  });

  mergeVal(ws, "B20:O20", "REGISTRO DE EVENTOS  ·  7 filas  ·  orden cronológico", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });

  const miniHead = ["ID", "Fecha_Hora", "Origen", "Destino / activo", "Tipo_Evento", "Sev.", "Método", "Estado"];
  const miniCols = [2, 3, 5, 7, 9, 12, 13, 15];
  const miniMerges = [
    [2, 2], [3, 4], [5, 6], [7, 8], [9, 11], [12, 12], [13, 14], [15, 15],
  ];
  miniHead.forEach((h, i) => {
    const [c1, c2] = miniMerges[i];
    if (c1 !== c2) ws.mergeCells(21, c1, 21, c2);
    const cell = ws.getCell(21, c1);
    cell.value = h;
    styleCell(cell, {
      fillArgb: C.surface2,
      font: font(8, { bold: true, color: C.muted }),
      alignment: align("left", "middle", false),
      border: thin(),
    });
    if (c1 !== c2) {
      for (let c = c1 + 1; c <= c2; c++) {
        styleCell(ws.getCell(21, c), { fillArgb: C.surface2, border: thin() });
      }
    }
  });

  EVENTS.forEach((ev, i) => {
    const r = 22 + i;
    const vals = [ev[0], ev[1], ev[2], `${ev[4]}  ${ev[5]}`, ev[6], ev[8], ev[9], ev[12]];
    vals.forEach((val, j) => {
      const [c1, c2] = miniMerges[j];
      if (c1 !== c2) ws.mergeCells(r, c1, r, c2);
      const cell = ws.getCell(r, c1);
      cell.value = val;
      let bg = i % 2 ? C.surface : C.surface2;
      let fg = C.fg;
      let bold = false;
      let mono = j === 0 || j === 2 || j === 3;
      if (j === 5) {
        bg = sevFill(ev[8]);
        fg = sevFg(ev[8]);
        bold = true;
        mono = false;
      }
      if (j === 7) {
        bg = estFill(ev[12]);
        fg = estFg(ev[12]);
        bold = true;
        mono = false;
      }
      styleCell(cell, {
        fillArgb: bg,
        font: font(9, { bold, color: fg, mono }),
        alignment: align("left", "middle", false),
        border: thin(),
      });
      if (c1 !== c2) {
        for (let c = c1 + 1; c <= c2; c++) {
          styleCell(ws.getCell(r, c), { fillArgb: bg, border: thin() });
        }
      }
    });
    ws.getRow(r).height = 20;
  });

  mergeVal(ws, "B30:O30", "LECTURA EJECUTIVA", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  mergeVal(
    ws,
    "B31:O33",
    "Entre el 1 oct 02:14 y el 3 oct 09:22 (55 h) un actor explotó el EMS de Caracas, cruzó de IT a OT en 4 minutos, inyectó DNP3 en una RTU, robó credenciales, borró la configuración de un HMI y tentó reflash de un PLC. Dos balizas C2 se bloquearon; el daño real está en OT (EVT-002, EVT-003, EVT-005). La familia FAM-PIVOTE sigue abierta (exfiltración EVT-004). Caracas aparece en las 7 geolocalizaciones (10.4806, −66.9036). No usar Electricity Maps / precios day-ahead: esto es telemetría de seguridad, no mercado eléctrico.",
    { font: font(10, { color: C.fg }), alignment: align("left", "top", true), fillArgb: C.card, border: thin() },
  );
  paint(ws, "B31:O33", C.card);

  mergeVal(ws, "B35:O35", "ACCIONES INMEDIATAS  (detalle en hoja 04 Análisis)", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  const acciones = [
    ["P0", "Aislar 10.0.50.0/24 y HMI 10.0.60.2. No reconectar a IT."],
    ["P0", "Reinstalar HMI desde imagen limpia. Verificar firmware RTU 10.0.50.12 y PLC 10.0.50.15."],
    ["P1", "Bloquear 198.51.100.22 / .44. Rotar credenciales EMS. Cuarentena 200.1.8–12.0/24."],
  ];
  acciones.forEach((a, i) => {
    const r = 36 + i;
    ws.mergeCells(r, 2, r, 2);
    ws.getCell(r, 2).value = a[0];
    styleCell(ws.getCell(r, 2), {
      fillArgb: a[0] === "P0" ? C.critBg : C.warnBg,
      font: font(10, { bold: true, color: a[0] === "P0" ? C.crit : C.high }),
      alignment: align("center", "middle", false),
      border: thin(),
    });
    ws.mergeCells(r, 3, r, 15);
    ws.getCell(r, 3).value = a[1];
    styleCell(ws.getCell(r, 3), {
      fillArgb: C.surface,
      font: font(10, { color: C.fg }),
      alignment: align("left", "middle", false),
      border: thin(),
    });
    ws.getRow(r).height = 20;
  });

  mergeVal(ws, "B40:O40", "Hojas:  01 Dashboard  ·  02 Eventos (tabla filtrable)  ·  03 Cadena de ataque  ·  04 Análisis  ·  05 Glosario", {
    font: font(8, { color: C.subtle }),
    alignment: align("left", "middle", false),
  });

  paint(ws, "A1:A42", C.ink);
  paint(ws, "P1:P42", C.ink);
  for (let r = 1; r <= 42; r++) {
    for (let c = 1; c <= 16; c++) {
      const cell = ws.getCell(r, c);
      if (!cell.fill) cell.fill = fill(C.ink);
    }
  }
  ws.getRow(1).height = 8;
  ws.getRow(5).height = 8;
  ws.getRow(9).height = 8;
  ws.getRow(19).height = 8;
  ws.getRow(29).height = 8;
  ws.getRow(34).height = 8;
}

function colLetter(n) {
  let s = "";
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

function buildEventos(wb) {
  const ws = wb.addWorksheet("02 Eventos", { views: [{ state: "frozen", ySplit: 1, showGridLines: false, zoomScale: 100 }] });
  setupSheet(ws, { tab: C.info, fitH: 1 });
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: HEADERS.length } };

  const widths = [10, 20, 15, 16, 16, 14, 26, 28, 12, 32, 26, 18, 14, 26, 18, 56];
  widths.forEach((w, i) => { ws.getColumn(i + 1).width = w; });

  HEADERS.forEach((h, i) => {
    const cell = ws.getCell(1, i + 1);
    cell.value = h;
    styleCell(cell, {
      fillArgb: C.banner,
      font: font(9, { bold: true, color: C.steel }),
      alignment: align("left", "middle", false),
      border: thin(C.line),
    });
  });
  ws.getRow(1).height = 22;

  EVENTS.forEach((ev, i) => {
    const r = i + 2;
    ev.forEach((val, j) => {
      const cell = ws.getCell(r, j + 1);
      cell.value = val;
      let bg = i % 2 ? C.surface : C.ink;
      let fg = C.fg;
      let bold = false;
      let mono = [0, 2, 3, 4, 10].includes(j);
      if (j === 8) {
        bg = sevFill(ev[8]);
        fg = sevFg(ev[8]);
        bold = true;
        mono = false;
      }
      if (j === 12) {
        bg = estFill(ev[12]);
        fg = estFg(ev[12]);
        bold = true;
        mono = false;
      }
      styleCell(cell, {
        fillArgb: bg,
        font: font(9, { bold, color: fg, mono }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
    ws.getRow(r).height = 32;
  });

  ws.addTable({
    name: "EventosICS",
    ref: `A1:P${EVENTS.length + 1}`,
    headerRow: true,
    totalsRow: false,
    style: { theme: "TableStyleMedium2", showRowStripes: false },
    columns: HEADERS.map((n) => ({ name: n, filterButton: true })),
    rows: EVENTS,
  });
}

function buildCadena(wb) {
  const ws = wb.addWorksheet("03 Cadena de ataque");
  setupSheet(ws, { tab: C.crit, fitH: 2 });
  const colW = [3, 16, 18, 22, 18, 18, 16, 16, 22, 36, 3];
  colW.forEach((w, i) => { ws.getColumn(i + 1).width = w; });

  paint(ws, "A1:K4", C.banner);
  mergeVal(ws, "B2:J2", "CADENA DE ATAQUE  ·  IT → OT  ·  Caracas", {
    font: font(18, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  mergeVal(ws, "B3:J3", "Misma campaña, tres familias. El cruce IT→OT ocurre 4 min 12 s después de la primera baliza.", {
    font: font(11, { color: C.muted }),
    alignment: align("left", "middle", false),
  });

  const chain = [
    { t: "+0 min", id: "EVT-001", title: "Beaconing C2", from: "200.1.8.45", to: "198.51.100.22  C2", how: "Explotación EMS", res: "Bloqueado", note: "La puerta se ve, no se abre." },
    { t: "+4 min", id: "EVT-002", title: "Pivote IT → OT", from: "200.1.9.112", to: "10.0.50.5  OT LAN", how: "Movimiento lateral", res: "Exitoso", note: "Aquí se pierde el perímetro." },
    { t: "+11 min", id: "EVT-003", title: "Inyección DNP3", from: "200.1.10.14", to: "10.0.50.12  RTU", how: "Protocolo ICS", res: "Exitoso", note: "Telecontrol eléctrico alterado." },
    { t: "+35 h 51 min", id: "EVT-004", title: "Exfiltración", from: "200.1.11.250", to: "198.51.100.44  C2", how: "Robo de credenciales", res: "Investigando", note: "Datos aún en tránsito o ya fuera." },
    { t: "+40 h 26 min", id: "EVT-005", title: "Wiper en HMI", from: "200.1.12.8", to: "10.0.60.2  HMI", how: "Borrado de config", res: "Exitoso", note: "Supervisión ciega." },
    { t: "+49 h 56 min", id: "EVT-006", title: "Reintento C2", from: "200.1.8.201", to: "198.51.100.22  C2", how: "Explotación EMS", res: "Bloqueado", note: "Mismo hash FAM-EMS-C2." },
    { t: "+55 h 08 min", id: "EVT-007", title: "Reflash PLC", from: "200.1.11.55", to: "10.0.50.15  PLC", how: "Firmware", res: "Bloqueado", note: "Persistencia de campo evitada." },
  ];

  const heads = ["Δt", "ID", "Fase", "Origen", "Destino", "Método", "Estado", "Lectura"];
  heads.forEach((h, i) => {
    const cell = ws.getCell(6, 2 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  ws.mergeCells("I6:J6");

  chain.forEach((step, i) => {
    const r = 7 + i;
    const vals = [step.t, step.id, step.title, step.from, step.to, step.how, step.res, step.note];
    vals.forEach((val, j) => {
      const c = 2 + j;
      if (j === 7) ws.mergeCells(r, 9, r, 10);
      const cell = ws.getCell(r, j === 7 ? 9 : c);
      cell.value = val;
      let bg = i % 2 ? C.surface : C.surface2;
      let fg = C.fg;
      let bold = false;
      let mono = j === 1 || j === 3 || j === 4;
      if (j === 6) {
        bg = estFill(step.res);
        fg = estFg(step.res);
        bold = true;
        mono = false;
      }
      styleCell(cell, {
        fillArgb: bg,
        font: font(10, { bold, color: fg, mono }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
    ws.getRow(r).height = 28;
  });

  mergeVal(ws, "B16:J16", "ARQUITECTURA TOCADA", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });

  const arch = [
    ["Zona", "CIDR / host", "Rol", "Eventos", "Estado resultante"],
    ["IT EMS", "200.1.8.0/24", "Energy Management System", "EVT-001, EVT-006", "C2 bloqueado; host probablemente infectado"],
    ["IT pivote", "200.1.9.0/24", "Salto IT→OT", "EVT-002", "Compromiso confirmado"],
    ["IT ICS", "200.1.10.0/24", "Origen de DNP3", "EVT-003", "Compromiso confirmado"],
    ["IT creds", "200.1.11.0/24", "Exfil + intento PLC", "EVT-004, EVT-007", "Credenciales robadas; PLC a salvo"],
    ["IT wiper", "200.1.12.0/24", "Despliegue malware", "EVT-005", "HMI destruido"],
    ["OT LAN", "10.0.50.5", "Backbone control", "EVT-002", "Pivote exitoso — aislar"],
    ["OT campo", "10.0.50.12 RTU", "Telecontrol subestación", "EVT-003", "DNP3 inyectado — auditar lógica"],
    ["OT campo", "10.0.50.15 PLC", "Control de proceso", "EVT-007", "Firmware bloqueado — verificar hash"],
    ["OT supervisión", "10.0.60.2 HMI", "Consola de operación", "EVT-005", "Config borrada — reinstalar"],
    ["C2", "198.51.100.22", "Beaconing", "EVT-001, EVT-006", "Sinkhole / block"],
    ["C2 exfil", "198.51.100.44", "Salida de datos", "EVT-004", "Sinkhole / block · forense"],
  ];
  arch.forEach((row, i) => {
    const r = 17 + i;
    row.forEach((val, j) => {
      const cell = ws.getCell(r, 2 + j);
      cell.value = val;
      const isH = i === 0;
      styleCell(cell, {
        fillArgb: isH ? C.surface2 : i % 2 ? C.surface : C.ink,
        font: font(9, { bold: isH || j === 0, color: isH ? C.muted : C.fg, mono: !isH && (j === 1 || j === 3) }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
    ws.getRow(r).height = i === 0 ? 18 : 22;
    ws.mergeCells(r, 6, r, 10);
  });

  mergeVal(ws, "B31:J32", "Tres hashes = tres herramientas. FAM-EMS-C2 (contenida) abre la puerta. FAM-PIVOTE (activa) cruza a OT y saca datos. FAM-ICS-PAYLOAD (parcial) habla DNP3, limpia el HMI e intenta dueñarse del PLC.", {
    font: font(10, { color: C.fg }),
    alignment: align("left", "top", true),
    fillArgb: C.card,
    border: thin(),
  });
  paint(ws, "B31:J32", C.card);
}

function buildAnalisis(wb) {
  const ws = wb.addWorksheet("04 Análisis");
  setupSheet(ws, { tab: C.high, fitH: 2 });
  const colW = [3, 12, 28, 14, 18, 18, 18, 22, 36, 3];
  colW.forEach((w, i) => { ws.getColumn(i + 1).width = w; });

  paint(ws, "A1:J3", C.banner);
  mergeVal(ws, "B2:I2", "ANÁLISIS  ·  familias, cobertura y acciones", {
    font: font(18, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });

  mergeVal(ws, "B5:I5", "FAMILIAS DE HASH", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  ["Familia", "Hash", "Eventos", "Rol", "Estado"].forEach((h, i) => {
    const cell = ws.getCell(6, 2 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  ws.mergeCells("F6:I6");
  const fams = [
    ["FAM-EMS-C2", "365ede59ae5b9332b9fb...", "EVT-001, EVT-006", "Canal C2 vía EMS", "Contenida"],
    ["FAM-PIVOTE", "77f2209a3a35b879ffdd...", "EVT-002, EVT-004", "Pivote IT→OT + robo de credenciales", "Activa / investigación"],
    ["FAM-ICS-PAYLOAD", "65b928be07f528ded928...", "EVT-003, EVT-005, EVT-007", "DNP3 + wiper + firmware", "Parcialmente contenida"],
  ];
  fams.forEach((row, i) => {
    const r = 7 + i;
    row.forEach((val, j) => {
      if (j === 4) ws.mergeCells(r, 6, r, 9);
      const cell = ws.getCell(r, j === 4 ? 6 : 2 + j);
      cell.value = val;
      let bg = C.surface;
      let fg = C.fg;
      if (j === 4) {
        if (val.startsWith("Contenida") && !val.includes("Parcial")) {
          bg = C.okBg; fg = C.ok;
        } else if (val.startsWith("Activa")) {
          bg = C.critBg; fg = C.crit;
        } else {
          bg = C.warnBg; fg = C.high;
        }
      }
      styleCell(cell, {
        fillArgb: bg,
        font: font(10, { bold: j === 0 || j === 4, color: fg, mono: j === 1 || j === 2 }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
    ws.getRow(r).height = 22;
  });

  mergeVal(ws, "B12:I12", "COBERTURA POR DÍA", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  ["Día", "Eventos", "Críticos", "Exitosos", "Bloqueados", "Hecho clave"].forEach((h, i) => {
    const cell = ws.getCell(13, 2 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  ws.mergeCells("G13:I13");
  const days = [
    ["1 oct 2026", 3, 2, 2, 1, "Intrusión inicial + cruce OT + DNP3 en 11 minutos"],
    ["2 oct 2026", 2, 1, 1, 0, "Exfil (abierta) y wiper de HMI"],
    ["3 oct 2026", 2, 1, 0, 2, "Reintento C2 y reflash PLC, ambos bloqueados"],
  ];
  days.forEach((row, i) => {
    const r = 14 + i;
    row.forEach((val, j) => {
      if (j === 5) ws.mergeCells(r, 7, r, 9);
      const cell = ws.getCell(r, j === 5 ? 7 : 2 + j);
      cell.value = val;
      styleCell(cell, {
        fillArgb: C.surface,
        font: font(10, { color: C.fg, mono: j >= 1 && j <= 4, bold: j === 0 }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
  });

  mergeVal(ws, "B18:I18", "PLAN DE RESPUESTA", {
    font: font(10, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });
  ["Prio", "Acción", "Por qué", "Dueño sugerido"].forEach((h, i) => {
    const cols = [2, 3, 6, 9];
    const cell = ws.getCell(19, cols[i]);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });
  ws.mergeCells("C19:E19");
  ws.mergeCells("F19:H19");
  const plan = [
    ["P0", "Aislar LAN OT 10.0.50.0/24 y HMI 10.0.60.2", "Cruce y DNP3 exitosos; no reconectar a IT", "Operaciones OT"],
    ["P0", "Reinstalar HMI desde imagen limpia", "Wiper EVT-005 borró configuración", "Ingeniería de supervisión"],
    ["P0", "Verificar firmware PLC 10.0.50.15 y RTU 10.0.50.12", "Reflash bloqueado, DNP3 no", "Mantenimiento de campo"],
    ["P1", "Bloquear 198.51.100.22 y .44 + sinkhole DNS", "C2 y canal de exfil", "SOC perimetral"],
    ["P1", "Rotar credenciales EMS, VPN y cuentas de ingeniería", "EVT-004 robo de credenciales", "IAM / EMS"],
    ["P1", "Cuarentena 200.1.8.0/24 – 200.1.12.0/24", "Todos los orígenes salen de esos /24", "Red IT"],
    ["P2", "Cazar las 3 familias (YARA/EDR + allow-list OT)", "EMS-C2 contenida; PIVOTE activa; ICS parcial", "Threat hunting"],
  ];
  plan.forEach((row, i) => {
    const r = 20 + i;
    ws.mergeCells(r, 3, r, 5);
    ws.mergeCells(r, 6, r, 8);
    const positions = [2, 3, 6, 9];
    row.forEach((val, j) => {
      const cell = ws.getCell(r, positions[j]);
      cell.value = val;
      let bg = C.surface;
      let fg = C.fg;
      if (j === 0) {
        bg = val === "P0" ? C.critBg : val === "P1" ? C.warnBg : C.infoBg;
        fg = val === "P0" ? C.crit : val === "P1" ? C.high : C.info;
      }
      styleCell(cell, {
        fillArgb: bg,
        font: font(10, { bold: j === 0, color: fg }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
    ws.getRow(r).height = 28;
  });

  mergeVal(ws, "B29:I30", "Indicador de riesgo residual: ALTO. OT fue tocado con éxito (LAN, RTU, HMI). El PLC se salvó. La exfiltración no está cerrada. Hasta aislar 10.0.50.0/24, reinstalar el HMI y rotar credenciales, el tablero no baja de ALTO.", {
    font: font(10, { color: C.fg }),
    alignment: align("left", "top", true),
    fillArgb: C.critBg,
    border: thin(),
  });
  paint(ws, "B29:I30", C.critBg);
}

function buildGlosario(wb) {
  const ws = wb.addWorksheet("05 Glosario");
  setupSheet(ws, { tab: C.ok, landscape: false, fitH: 2 });
  ws.getColumn(1).width = 3;
  ws.getColumn(2).width = 24;
  ws.getColumn(3).width = 88;
  ws.getColumn(4).width = 3;

  paint(ws, "A1:D3", C.banner);
  mergeVal(ws, "B2:C2", "GLOSARIO  ·  para leer el tablero sin jerga suelta", {
    font: font(16, { bold: true, color: C.steel }),
    alignment: align("left", "middle", false),
  });

  const glossary = [
    ["Fecha_Hora", "Marca temporal local de Caracas (UTC−4) en que se observó el evento."],
    ["IP_Origen", "Host que inició la acción. Rangos 200.1.x.x = red IT de distribución Caracas."],
    ["Segmento", "Subred /24 del origen. Sirve para aislar o poner en cuarentena un anillo completo."],
    ["IP_Destino", "Objetivo. 10.0.50.x y 10.0.60.x = OT; 198.51.100.x = infraestructura C2 (documentación/TEST-NET)."],
    ["Tipo_Evento", "Qué se vio: baliza C2, cruce lateral, inyección ICS, exfil, malware o cambio de firmware."],
    ["Coordenadas_Aprox", "Geolocalización del origen. Las 7 filas apuntan a Caracas 10.4806, −66.9036."],
    ["Severidad", "Alta = compromiso IT/C2. Crítica = toca activos de control (RTU, PLC, HMI, LAN OT)."],
    ["Metodo_Ataque", "Técnica usada. EMS, DNP3, wiper y firmware son las más graves en un sistema eléctrico."],
    ["Hash_Asociado", "Huella del artefacto. El mismo hash en varios eventos = misma familia de malware."],
    ["Estado", "Bloqueado = el control detuvo el acto. Exitoso = el acto ocurrió. Investigando = aún abierto."],
    ["EMS", "Energy Management System: software que supervisa y despacha la red eléctrica."],
    ["RTU", "Remote Terminal Unit: equipo de campo que lee sensores y ejecuta órdenes en subestaciones."],
    ["PLC", "Programmable Logic Controller: controlador de proceso. Un firmware malicioso lo deja capturado."],
    ["HMI", "Human-Machine Interface: pantalla de operación. Un wiper borra la configuración de supervisión."],
    ["DNP3", "Protocolo estándar de telecontrol eléctrico. Paquetes inyectados pueden falsear medidas o mandos."],
    ["Beaconing C2", "El host infectado llama a un servidor de comando y control para pedir órdenes."],
    ["Wiper", "Malware que borra, no espía. Aquí apuntó a la configuración del HMI."],
    ["Pivote IT a OT", "Saltar de la red de oficinas/EMS a la red que mueve interruptores y protecciones."],
    ["FAM-EMS-C2", "Familia 365ede59… Balizas al C2 198.51.100.22. Estado: contenida."],
    ["FAM-PIVOTE", "Familia 77f2209a… Cruce a OT + exfil. Estado: activa, investigación abierta."],
    ["FAM-ICS-PAYLOAD", "Familia 65b928be… DNP3, wiper y firmware. Estado: parcialmente contenida."],
  ];

  ["Campo / término", "Qué significa en este informe"].forEach((h, i) => {
    const cell = ws.getCell(4, 2 + i);
    cell.value = h;
    styleCell(cell, { fillArgb: C.surface2, font: font(9, { bold: true, color: C.muted }), alignment: align("left", "middle", false), border: thin() });
  });

  glossary.forEach((row, i) => {
    const r = 5 + i;
    row.forEach((val, j) => {
      const cell = ws.getCell(r, 2 + j);
      cell.value = val;
      styleCell(cell, {
        fillArgb: i % 2 ? C.surface : C.ink,
        font: font(10, { bold: j === 0, color: j === 0 ? C.steel : C.fg, mono: j === 0 && val.startsWith("FAM") }),
        alignment: align("left", "middle", true),
        border: thin(),
      });
    });
    ws.getRow(r).height = 28;
  });
}

build().catch((err) => {
  console.error(err);
  process.exit(1);
});
