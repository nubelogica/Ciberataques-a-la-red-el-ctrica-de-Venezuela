//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DGRlQhV2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-9VcAYCg-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9VcAYCg-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BYjIrmsB.js"]
	}
} });
//#endregion
export { tsrStartManifest };
