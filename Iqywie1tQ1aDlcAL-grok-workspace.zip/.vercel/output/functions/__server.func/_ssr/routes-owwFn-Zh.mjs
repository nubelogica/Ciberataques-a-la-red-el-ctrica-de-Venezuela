import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Download, i as Radio, n as ShieldCheck, r as ShieldAlert } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as Bar, c as Tooltip, i as CartesianGrid, n as YAxis, o as Cell, r as XAxis, s as ResponsiveContainer, t as BarChart } from "../_libs/recharts+[...].mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-owwFn-Zh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2",
			ghost: "text-muted hover:text-fg hover:bg-surface-2"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var SITE = {
	name: "GRIDWATCH",
	org: "Corpoelec · Electricidad de Caracas",
	zona: "Caracas, VE",
	coords: "10.4806, -66.9036",
	ventana: "1–3 octubre 2026",
	clasificacion: "CONFIDENCIAL · Uso interno SOC/OT"
};
var INCIDENTS = [
	{
		id: "EVT-001",
		fechaHora: "2026-10-01 02:14:00",
		ts: Date.parse("2026-10-01T02:14:00-04:00"),
		ipOrigen: "200.1.8.45",
		segmento: "200.1.8.0/24",
		ipDestino: "198.51.100.22",
		destinoLabel: "C2 externo",
		zonaDestino: "C2",
		tipoEvento: "Beaconing C2",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Alta",
		metodoAtaque: "Explotacion EMS",
		hash: "365ede59ae5b9332b9fb...",
		hashFamilia: "FAM-EMS-C2",
		estado: "Bloqueado",
		fase: "1. Comando y control",
		mitre: "ICS T0885 / T0869",
		impacto: "Baliza C2 bloqueada en el perímetro. No hubo sesión establecida."
	},
	{
		id: "EVT-002",
		fechaHora: "2026-10-01 02:18:12",
		ts: Date.parse("2026-10-01T02:18:12-04:00"),
		ipOrigen: "200.1.9.112",
		segmento: "200.1.9.0/24",
		ipDestino: "10.0.50.5",
		destinoLabel: "OT LAN",
		zonaDestino: "OT",
		tipoEvento: "Movimiento Lateral",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Critica",
		metodoAtaque: "Pivote IT a OT",
		hash: "77f2209a3a35b879ffdd...",
		hashFamilia: "FAM-PIVOTE",
		estado: "Exitoso",
		fase: "2. Cruce de air-gap lógico",
		mitre: "ICS T0866 / T0886",
		impacto: "El atacante cruzó de la red IT al LAN OT. Punto de no retorno operativo."
	},
	{
		id: "EVT-003",
		fechaHora: "2026-10-01 02:25:30",
		ts: Date.parse("2026-10-01T02:25:30-04:00"),
		ipOrigen: "200.1.10.14",
		segmento: "200.1.10.0/24",
		ipDestino: "10.0.50.12",
		destinoLabel: "RTU",
		zonaDestino: "OT",
		tipoEvento: "Inyeccion de Paquetes ICS",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Critica",
		metodoAtaque: "Manipulacion Protocolo DNP3",
		hash: "65b928be07f528ded928...",
		hashFamilia: "FAM-ICS-PAYLOAD",
		estado: "Exitoso",
		fase: "3. Manipulación de control",
		mitre: "ICS T0831 / T0836",
		impacto: "Paquetes DNP3 inyectados a una RTU. Posible alteración de telemetría o consigna."
	},
	{
		id: "EVT-004",
		fechaHora: "2026-10-02 14:05:22",
		ts: Date.parse("2026-10-02T14:05:22-04:00"),
		ipOrigen: "200.1.11.250",
		segmento: "200.1.11.0/24",
		ipDestino: "198.51.100.44",
		destinoLabel: "Exfil C2",
		zonaDestino: "C2",
		tipoEvento: "Exfiltracion de Datos",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Alta",
		metodoAtaque: "Robo de Credenciales",
		hash: "77f2209a3a35b879ffdd...",
		hashFamilia: "FAM-PIVOTE",
		estado: "Investigando",
		fase: "4. Exfiltración",
		mitre: "ICS T0893 / T0882",
		impacto: "Salida de datos hacia 198.51.100.44. Alcance de lo robado aún no cerrado."
	},
	{
		id: "EVT-005",
		fechaHora: "2026-10-02 18:40:00",
		ts: Date.parse("2026-10-02T18:40:00-04:00"),
		ipOrigen: "200.1.12.8",
		segmento: "200.1.12.0/24",
		ipDestino: "10.0.60.2",
		destinoLabel: "HMI",
		zonaDestino: "OT",
		tipoEvento: "Despliegue de Malware",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Critica",
		metodoAtaque: "Wiper (Borrado de Configuración)",
		hash: "65b928be07f528ded928...",
		hashFamilia: "FAM-ICS-PAYLOAD",
		estado: "Exitoso",
		fase: "5. Impacto / destrucción",
		mitre: "ICS T0826 / T0872",
		impacto: "Wiper en HMI. Pérdida de configuración de supervisión. Recuperar desde backup limpio."
	},
	{
		id: "EVT-006",
		fechaHora: "2026-10-03 04:10:15",
		ts: Date.parse("2026-10-03T04:10:15-04:00"),
		ipOrigen: "200.1.8.201",
		segmento: "200.1.8.0/24",
		ipDestino: "198.51.100.22",
		destinoLabel: "C2 externo",
		zonaDestino: "C2",
		tipoEvento: "Beaconing C2",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Alta",
		metodoAtaque: "Explotacion EMS",
		hash: "365ede59ae5b9332b9fb...",
		hashFamilia: "FAM-EMS-C2",
		estado: "Bloqueado",
		fase: "1. Comando y control",
		mitre: "ICS T0885 / T0869",
		impacto: "Segunda baliza al mismo C2, bloqueada. El actor reintenta el canal EMS."
	},
	{
		id: "EVT-007",
		fechaHora: "2026-10-03 09:22:45",
		ts: Date.parse("2026-10-03T09:22:45-04:00"),
		ipOrigen: "200.1.11.55",
		segmento: "200.1.11.0/24",
		ipDestino: "10.0.50.15",
		destinoLabel: "PLC",
		zonaDestino: "OT",
		tipoEvento: "Intento de Modificacion",
		lat: 10.4806,
		lon: -66.9036,
		ciudad: "Caracas",
		coordenadas: "10.4806,-66.9036 (Caracas)",
		severidad: "Critica",
		metodoAtaque: "Sobrescritura de Firmware",
		hash: "65b928be07f528ded928...",
		hashFamilia: "FAM-ICS-PAYLOAD",
		estado: "Bloqueado",
		fase: "6. Persistencia en campo",
		mitre: "ICS T0857",
		impacto: "Intento de reflash de PLC detenido. Si hubiera pasado, el control quedaba en manos del actor."
	}
];
var FAMILIAS = [
	{
		id: "FAM-EMS-C2",
		hash: "365ede59ae5b9332b9fb...",
		rol: "Canal C2 vía EMS",
		eventos: ["EVT-001", "EVT-006"],
		estado: "Contenida"
	},
	{
		id: "FAM-PIVOTE",
		hash: "77f2209a3a35b879ffdd...",
		rol: "Pivote IT→OT y robo de credenciales",
		eventos: ["EVT-002", "EVT-004"],
		estado: "Activa / en investigación"
	},
	{
		id: "FAM-ICS-PAYLOAD",
		hash: "65b928be07f528ded928...",
		rol: "Payload ICS (DNP3, wiper, firmware)",
		eventos: [
			"EVT-003",
			"EVT-005",
			"EVT-007"
		],
		estado: "Parcialmente contenida"
	}
];
var GLOSARIO = [
	{
		termino: "Fecha_Hora",
		significado: "Marca temporal local de Caracas (UTC−4) en que se observó el evento."
	},
	{
		termino: "IP_Origen",
		significado: "Host que inició la acción. Rangos 200.1.x.x = red IT de distribución Caracas."
	},
	{
		termino: "Segmento",
		significado: "Subred /24 del origen. Sirve para aislar o poner en cuarentena un anillo completo."
	},
	{
		termino: "IP_Destino",
		significado: "Objetivo de la conexión. 10.0.50.x/10.0.60.x = OT; 198.51.100.x = infraestructura C2."
	},
	{
		termino: "Tipo_Evento",
		significado: "Qué se vio: baliza C2, cruce lateral, inyección ICS, exfil, malware o cambio de firmware."
	},
	{
		termino: "Coordenadas_Aprox",
		significado: "Geolocalización aproximada del origen (Caracas 10.4806, −66.9036)."
	},
	{
		termino: "Severidad",
		significado: "Alta = compromiso IT/C2. Crítica = toca activos de control (RTU, PLC, HMI, LAN OT)."
	},
	{
		termino: "Metodo_Ataque",
		significado: "Técnica usada. EMS, DNP3, wiper y firmware son las más graves en un sistema eléctrico."
	},
	{
		termino: "Hash_Asociado",
		significado: "Huella del artefacto. El mismo hash en varios eventos = misma familia de malware."
	},
	{
		termino: "Estado",
		significado: "Bloqueado = control de seguridad detuvo el acto. Exitoso = el acto ocurrió. Investigando = aún abierto."
	},
	{
		termino: "EMS",
		significado: "Energy Management System: software que supervisa y despacha la red eléctrica."
	},
	{
		termino: "RTU",
		significado: "Remote Terminal Unit: equipo de campo que lee sensores y ejecuta órdenes en subestaciones."
	},
	{
		termino: "PLC",
		significado: "Programmable Logic Controller: controlador de proceso. Un firmware malicioso lo deja capturado."
	},
	{
		termino: "HMI",
		significado: "Human-Machine Interface: pantalla de operación. Un wiper borra la configuración de supervisión."
	},
	{
		termino: "DNP3",
		significado: "Protocolo estándar de telecontrol eléctrico. Paquetes inyectados pueden falsear medidas o mandos."
	},
	{
		termino: "Beaconing C2",
		significado: "El host infectado llama a un servidor de comando y control para pedir órdenes."
	},
	{
		termino: "Wiper",
		significado: "Malware que borra, no espía. Aquí apuntó a la configuración del HMI."
	}
];
var RECOMENDACIONES = [
	{
		prioridad: "P0",
		titulo: "Aislar LAN OT 10.0.50.0/24 y HMI 10.0.60.2",
		detalle: "EVT-002 y EVT-003 cruzaron a OT y tocaron una RTU. Sacar de producción, modo manual seguro, no reconectar a IT."
	},
	{
		prioridad: "P0",
		titulo: "Reinstalar HMI desde imagen limpia",
		detalle: "EVT-005 (wiper) fue exitoso. No confiar en la config actual. Restaurar backup verificado anterior al 1 oct."
	},
	{
		prioridad: "P0",
		titulo: "Verificar firmware de PLC 10.0.50.15 y RTU 10.0.50.12",
		detalle: "El reflash se bloqueó, la inyección DNP3 no. Comparar hashes de firmware y lógica contra el gold image."
	},
	{
		prioridad: "P1",
		titulo: "Cortar 198.51.100.22 y 198.51.100.44",
		detalle: "C2 y exfil. Bloqueo perimetral + DNS sinkhole. Buscar más balizas al mismo /24."
	},
	{
		prioridad: "P1",
		titulo: "Rotar credenciales del EMS y cuentas de ingeniería",
		detalle: "EVT-004 indica robo de credenciales (familia FAM-PIVOTE). Invalidar tokens, VPN y cuentas de servicio."
	},
	{
		prioridad: "P1",
		titulo: "Cuarentena de segmentos 200.1.8–12.0/24",
		detalle: "Todos los orígenes salen de esos /24 IT. Forense en 200.1.9.112 (pivote) y 200.1.12.8 (wiper)."
	},
	{
		prioridad: "P2",
		titulo: "Cazar las 3 familias de hash",
		detalle: "EMS-C2 contenida; PIVOTE activa; ICS-PAYLOAD parcialmente contenida. EDR/YARA en IT y allow-list en OT."
	}
];
function countBy(rows, key) {
	const out = {};
	for (const row of rows) {
		const k = key(row);
		out[k] = (out[k] ?? 0) + 1;
	}
	return out;
}
function buildStats(rows = INCIDENTS) {
	const total = rows.length;
	const porSeveridad = countBy(rows, (r) => r.severidad);
	const porEstado = countBy(rows, (r) => r.estado);
	const porTipo = countBy(rows, (r) => r.tipoEvento);
	const porMetodo = countBy(rows, (r) => r.metodoAtaque);
	const porZona = countBy(rows, (r) => r.zonaDestino);
	const criticos = porSeveridad.Critica ?? 0;
	const altas = porSeveridad.Alta ?? 0;
	const bloqueados = porEstado.Bloqueado ?? 0;
	const exitosos = porEstado.Exitoso ?? 0;
	const investigando = porEstado.Investigando ?? 0;
	const contencion = total ? Math.round(bloqueados / total * 100) : 0;
	const hashes = new Set(rows.map((r) => r.hash)).size;
	const segmentos = new Set(rows.map((r) => r.segmento)).size;
	const otComprometido = rows.some((r) => r.zonaDestino === "OT" && r.estado === "Exitoso");
	const first = rows[0];
	const last = rows[rows.length - 1];
	return {
		total,
		criticos,
		altas,
		bloqueados,
		exitosos,
		investigando,
		contencion,
		hashes,
		segmentos,
		otComprometido,
		ventanaHoras: first && last ? (last.ts - first.ts) / 36e5 : 0,
		porSeveridad,
		porEstado,
		porTipo,
		porMetodo,
		porZona
	};
}
var STATS = buildStats();
var CHART = {
	fg: "#e8edf2",
	muted: "#8b98a5",
	grid: "#2a343e",
	crit: "#e11d48",
	high: "#d97706",
	ok: "#0f9d7a",
	info: "#5b8fb3",
	steel: "#c5ccd4",
	surface: "#1b232c"
};
var TABS = [
	{
		id: "resumen",
		label: "Resumen"
	},
	{
		id: "eventos",
		label: "Eventos"
	},
	{
		id: "cadena",
		label: "Cadena"
	},
	{
		id: "analisis",
		label: "Análisis"
	},
	{
		id: "glosario",
		label: "Glosario"
	}
];
var panel = "rounded-xl border border-border bg-surface";
var card = "rounded-lg border border-border bg-surface";
function SocDashboard() {
	const [tab, setTab] = (0, import_react.useState)("resumen");
	const [sev, setSev] = (0, import_react.useState)("Todas");
	const [est, setEst] = (0, import_react.useState)("Todos");
	const [openId, setOpenId] = (0, import_react.useState)(INCIDENTS[1]?.id ?? null);
	const filtered = (0, import_react.useMemo)(() => INCIDENTS.filter((row) => (sev === "Todas" || row.severidad === sev) && (est === "Todos" || row.estado === est)), [sev, est]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "border-b border-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:px-6 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-muted uppercase",
							children: "SOC / OT · confidencial"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-2xl font-semibold tracking-tight text-fg sm:text-3xl",
							children: SITE.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								SITE.org,
								" · ",
								SITE.zona,
								" · ",
								SITE.ventana
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "w-full shrink-0 sm:w-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/GRIDWATCH_ICS.xlsx",
						download: "GRIDWATCH_ICS.xlsx",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Descargar Excel"]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-px sm:px-6",
				"aria-label": "Hojas del tablero",
				children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(item.id),
					className: cn("relative h-11 shrink-0 px-3 text-sm font-medium transition-colors duration-150", tab === item.id ? "text-fg" : "text-muted hover:text-fg"),
					children: [item.label, tab === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-x-2 bottom-0 h-px bg-accent" }) : null]
				}, item.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
			children: [
				tab === "resumen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Resumen, { onOpen: (id) => {
					setOpenId(id);
					setTab("eventos");
				} }) : null,
				tab === "eventos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eventos, {
					rows: filtered,
					sev,
					est,
					onSev: setSev,
					onEst: setEst,
					openId,
					onOpen: setOpenId
				}) : null,
				tab === "cadena" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cadena, { onOpen: (id) => {
					setOpenId(id);
					setTab("eventos");
				} }) : null,
				tab === "analisis" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Analisis, {}) : null,
				tab === "glosario" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glosario, {}) : null
			]
		})]
	});
}
function Resumen({ onOpen }) {
	const tipoData = Object.entries(STATS.porTipo).map(([name, n]) => ({
		name: {
			"Beaconing C2": "Beaconing C2",
			"Movimiento Lateral": "Pivote IT→OT",
			"Inyeccion de Paquetes ICS": "Inyección ICS",
			"Exfiltracion de Datos": "Exfiltración",
			"Despliegue de Malware": "Wiper HMI",
			"Intento de Modificacion": "Firmware PLC"
		}[name] ?? name,
		n
	}));
	const estadoData = [
		{
			name: "Exitoso",
			n: STATS.exitosos,
			fill: CHART.crit
		},
		{
			name: "Bloqueado",
			n: STATS.bloqueados,
			fill: CHART.ok
		},
		{
			name: "Investigando",
			n: STATS.investigando,
			fill: CHART.high
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-7 lg:gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Eventos",
						value: String(STATS.total),
						hint: "en 55 h 08 min"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Críticos",
						value: String(STATS.criticos),
						hint: "tocan activos OT",
						tone: "crit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Exitosos",
						value: String(STATS.exitosos),
						hint: "el acto ocurrió",
						tone: "crit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Bloqueados",
						value: String(STATS.bloqueados),
						hint: "contenidos",
						tone: "ok"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Contención",
						value: `${STATS.contencion}%`,
						hint: "3 de 7 detenidos",
						tone: "high"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Familias",
						value: String(STATS.hashes),
						hint: "hashes únicos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Segmentos",
						value: String(STATS.segmentos),
						hint: "IT 200.1.8–12/24",
						className: "col-span-2 sm:col-span-1"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cn(panel, "p-4 sm:p-5"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-muted",
						children: "Lectura ejecutiva"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-4xl text-sm leading-relaxed text-fg",
						children: [
							"Entre el 1 oct 02:14 y el 3 oct 09:22 un actor explotó el EMS de Caracas, cruzó de IT a OT en cuatro minutos, inyectó DNP3 en una RTU, robó credenciales, borró la configuración de un HMI e intentó reflash de un PLC. Dos balizas C2 se bloquearon; el daño real está en OT (EVT-002, EVT-003, EVT-005). La familia FAM-PIVOTE sigue abierta. Las siete geolocalizaciones apuntan a ",
							SITE.coords,
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex items-center gap-2 text-xs font-medium text-crit",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 shrink-0" }), "Riesgo residual: ALTO · OT comprometido · exfiltración sin cerrar"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartCard, {
					title: "Tipo de evento",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: 220,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: tipoData,
							layout: "vertical",
							margin: {
								left: 8,
								right: 12,
								top: 4,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: CHART.grid,
									horizontal: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									type: "number",
									allowDecimals: false,
									stroke: CHART.muted,
									tick: {
										fill: CHART.muted,
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									type: "category",
									dataKey: "name",
									width: 96,
									stroke: CHART.muted,
									tick: {
										fill: CHART.fg,
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}),
									cursor: { fill: CHART.surface }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "n",
									radius: [
										0,
										3,
										3,
										0
									],
									fill: CHART.steel,
									barSize: 12
								})
							]
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartCard, {
					title: "Estado",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: 220,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: estadoData,
							margin: {
								left: 0,
								right: 8,
								top: 8,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: CHART.grid,
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									stroke: CHART.muted,
									tick: {
										fill: CHART.fg,
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									allowDecimals: false,
									stroke: CHART.muted,
									tick: {
										fill: CHART.muted,
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}),
									cursor: { fill: CHART.surface }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "n",
									radius: [
										3,
										3,
										0,
										0
									],
									barSize: 28,
									children: estadoData.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: d.fill }, d.name))
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-medium text-muted",
				children: "Registro · toca una fila para el detalle"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTable, {
				rows: INCIDENTS,
				openId: null,
				onOpen,
				compact: true
			})] })
		]
	});
}
function Eventos({ rows, sev, est, onSev, onEst, openId, onOpen }) {
	const selected = INCIDENTS.find((r) => r.id === openId) ?? rows[0] ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						rows.length,
						" de ",
						INCIDENTS.length,
						" eventos · filtros combinables"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterGroup, {
						label: "Severidad",
						value: sev,
						options: [
							"Todas",
							"Critica",
							"Alta"
						],
						onChange: (v) => onSev(v)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterGroup, {
						label: "Estado",
						value: est,
						options: [
							"Todos",
							"Exitoso",
							"Bloqueado",
							"Investigando"
						],
						onChange: (v) => onEst(v)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTable, {
				rows,
				openId,
				onOpen
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncidentDetail, { row: selected }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn(card, "px-4 py-6 text-sm text-muted"),
				children: "Ningún evento con esos filtros."
			})
		]
	});
}
function Cadena({ onOpen }) {
	const deltas = [
		"+0 min",
		"+4 min",
		"+11 min",
		"+35 h 51 min",
		"+40 h 26 min",
		"+49 h 56 min",
		"+55 h 08 min"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cn(panel, "p-4 sm:p-5"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-muted",
					children: "IT → OT en once minutos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-3xl text-sm leading-relaxed text-fg",
					children: "La primera baliza se bloquea. Cuatro minutos después el pivote ya está en el LAN OT. Siete minutos más y hay DNP3 en una RTU. El resto de la campaña (exfil, wiper, reflash) ocurre en las 55 horas siguientes con las mismas tres familias de hash."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-2",
				children: INCIDENTS.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(row.id),
					className: "flex w-full flex-col gap-2 rounded-lg border border-border bg-surface px-4 py-3 text-left transition-colors duration-150 hover:bg-surface-2 sm:flex-row sm:items-center sm:gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-muted tabular-nums sm:w-28",
							children: deltas[i]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-subtle sm:w-16",
							children: row.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 text-sm font-medium text-fg",
							children: row.tipoEvento
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-xs text-muted",
							children: [
								row.ipOrigen,
								" → ",
								row.destinoLabel
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstadoBadge, { estado: row.estado })
					]
				}) }, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-medium text-muted",
				children: "Arquitectura tocada"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-surface-2 text-xs tracking-wide text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2.5 font-medium",
								children: "Zona"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2.5 font-medium",
								children: "Host"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2.5 font-medium",
								children: "Rol"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2.5 font-medium",
								children: "Resultado"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "bg-surface",
						children: [
							[
								"IT EMS",
								"200.1.8.0/24",
								"Energy Management",
								"C2 bloqueado; host infectado"
							],
							[
								"OT LAN",
								"10.0.50.5",
								"Backbone de control",
								"Pivote exitoso — aislar"
							],
							[
								"OT campo",
								"10.0.50.12",
								"RTU",
								"DNP3 inyectado — auditar"
							],
							[
								"OT campo",
								"10.0.50.15",
								"PLC",
								"Firmware bloqueado — verificar hash"
							],
							[
								"OT supervisión",
								"10.0.60.2",
								"HMI",
								"Config borrada — reinstalar"
							],
							[
								"C2",
								"198.51.100.22 / .44",
								"Beacon + exfil",
								"Sinkhole y bloqueo"
							]
						].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 text-fg",
									children: r[0]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 font-mono text-xs text-muted",
									children: r[1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 text-muted",
									children: r[2]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 text-fg",
									children: r[3]
								})
							]
						}, r[1]))
					})]
				})
			})] })
		]
	});
}
function Analisis() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-sm font-medium text-muted",
			children: "Tres familias de hash"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-3",
			children: FAMILIAS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: cn(card, "p-4"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-subtle",
						children: f.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-xs text-muted",
						children: f.hash
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-fg",
						children: f.rol
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: f.eventos.join(" · ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs font-medium text-accent",
						children: f.estado
					})
				]
			}, f.id))
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-sm font-medium text-muted",
			children: "Plan de respuesta"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children: RECOMENDACIONES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn(card, "flex flex-col gap-1 px-4 py-3 sm:flex-row sm:gap-4"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("font-mono text-xs font-medium sm:w-8", r.prioridad === "P0" ? "text-crit" : r.prioridad === "P1" ? "text-high" : "text-info"),
					children: r.prioridad
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: r.titulo
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: r.detalle
					})]
				})]
			}, r.titulo))
		})] })]
	});
}
function Glosario() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-sm text-muted",
			children: "Cómo leer cada columna del Excel y los acrónimos de planta."
		}), GLOSARIO.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-1 rounded-md border border-border bg-surface px-4 py-3 sm:grid-cols-[14rem_1fr] sm:gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-sm text-accent",
				children: g.termino
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-fg",
				children: g.significado
			})]
		}, g.termino))]
	});
}
function Kpi({ label, value, hint, tone, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn(card, "px-3 py-3 sm:px-4", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 font-mono text-2xl font-medium tabular-nums", tone === "crit" ? "text-crit" : tone === "ok" ? "text-ok" : tone === "high" ? "text-high" : "text-fg"),
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-subtle",
				children: hint
			})
		]
	});
}
function ChartCard({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn(panel, "p-4 sm:p-5"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-sm font-medium text-muted",
			children: title
		}), children]
	});
}
function ChartTip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm border border-border bg-surface-2 px-2 py-1 text-xs text-fg",
		children: [
			label,
			": ",
			payload[0]?.value
		]
	});
}
function FilterGroup({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1 rounded-sm border border-border bg-surface p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: label
		}), options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(opt),
			className: cn("h-9 rounded-xs px-3 text-xs font-medium transition-colors duration-150", value === opt ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
			children: opt
		}, opt))]
	});
}
function EventTable({ rows, openId, onOpen, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-lg border border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "bg-surface-2 text-xs tracking-wide text-muted uppercase",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "ID"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "Fecha_Hora"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "IP_Origen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "IP_Destino"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "Tipo_Evento"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "Severidad"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "Estado"
					}),
					compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2.5 font-medium whitespace-nowrap",
						children: "Metodo_Ataque"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
				className: "bg-surface",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					onClick: () => onOpen(row.id),
					className: cn("cursor-pointer border-t border-border transition-colors duration-150 hover:bg-surface-2", openId === row.id && "bg-surface-2"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 font-mono text-xs text-subtle",
							children: row.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 font-mono text-xs tabular-nums",
							children: row.fechaHora
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 font-mono text-xs",
							children: row.ipOrigen
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-3 py-2.5 font-mono text-xs",
							children: [row.ipDestino, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-1 text-subtle",
								children: [" ", row.destinoLabel]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5",
							children: row.tipoEvento
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SevBadge, { severidad: row.severidad })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstadoBadge, { estado: row.estado })
						}),
						compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 text-muted",
							children: row.metodoAtaque
						})
					]
				}, row.id))
			})]
		})
	});
}
function IncidentDetail({ row }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn(panel, "grid gap-4 p-4 sm:p-5 lg:grid-cols-3"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-subtle",
							children: row.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SevBadge, { severidad: row.severidad }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstadoBadge, { estado: row.estado })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 text-lg font-medium text-fg",
					children: row.tipoEvento
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: row.impacto
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "grid grid-cols-2 gap-x-3 gap-y-2 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Fecha_Hora",
					v: row.fechaHora,
					mono: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Fase",
					v: row.fase
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "IP_Origen",
					v: row.ipOrigen,
					mono: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Segmento",
					v: row.segmento,
					mono: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "IP_Destino",
					v: `${row.ipDestino} (${row.destinoLabel})`,
					mono: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Coordenadas",
					v: row.coordenadas
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Metodo_Ataque",
					v: row.metodoAtaque
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "MITRE",
					v: row.mitre,
					mono: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Hash_Asociado",
					v: row.hash,
					mono: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					k: "Familia",
					v: row.hashFamilia,
					mono: true
				})
			]
		})]
	});
}
function Item({ k, v, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs tracking-wide text-subtle uppercase",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: cn("mt-0.5 text-fg", mono && "font-mono text-xs"),
		children: v
	})] });
}
function SevBadge({ severidad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-6 items-center rounded-xs px-2 text-xs font-medium tracking-wide uppercase", severidad === "Critica" ? "bg-crit/15 text-crit" : "bg-high/15 text-high"),
		children: severidad
	});
}
function EstadoBadge({ estado }) {
	const Icon = estado === "Bloqueado" ? ShieldCheck : estado === "Exitoso" ? ShieldAlert : Radio;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex h-6 items-center gap-1 rounded-xs px-2 text-xs font-medium tracking-wide uppercase", estado === "Bloqueado" ? "bg-ok/15 text-ok" : estado === "Exitoso" ? "bg-crit/15 text-crit" : "bg-high/15 text-high"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }), estado]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocDashboard, {});
}
//#endregion
export { Home as component };
