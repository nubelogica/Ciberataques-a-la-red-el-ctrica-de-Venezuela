import { useMemo, useState, type ReactNode } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Download, Radio, ShieldAlert, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  CHART,
  FAMILIAS,
  GLOSARIO,
  INCIDENTS,
  RECOMENDACIONES,
  SITE,
  STATS,
  type Estado,
  type Incident,
  type Severidad,
} from "@/lib/incidents";
import { cn } from "@/lib/utils";

const TABS = [
  { id: "resumen", label: "Resumen" },
  { id: "eventos", label: "Eventos" },
  { id: "cadena", label: "Cadena" },
  { id: "analisis", label: "Análisis" },
  { id: "glosario", label: "Glosario" },
] as const;

type TabId = (typeof TABS)[number]["id"];

const panel = "rounded-xl border border-border bg-surface";
const card = "rounded-lg border border-border bg-surface";

export function SocDashboard() {
  const [tab, setTab] = useState<TabId>("resumen");
  const [sev, setSev] = useState<Severidad | "Todas">("Todas");
  const [est, setEst] = useState<Estado | "Todos">("Todos");
  const [openId, setOpenId] = useState<string | null>(INCIDENTS[1]?.id ?? null);

  const filtered = useMemo(
    () =>
      INCIDENTS.filter((row) => (sev === "Todas" || row.severidad === sev) && (est === "Todos" || row.estado === est)),
    [sev, est],
  );

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:px-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="min-w-0">
            <p className="font-mono text-xs tracking-widest text-muted uppercase">
              SOC / OT · confidencial
            </p>
            <h1 className="mt-1 text-2xl font-semibold tracking-tight text-fg sm:text-3xl">
              {SITE.name}
            </h1>
            <p className="mt-1 text-sm text-muted">
              {SITE.org} · {SITE.zona} · {SITE.ventana}
            </p>
          </div>
          <Button asChild className="w-full shrink-0 sm:w-auto">
            <a href="/GRIDWATCH_ICS.xlsx" download="GRIDWATCH_ICS.xlsx">
              <Download className="size-4" />
              Descargar Excel
            </a>
          </Button>
        </div>
        <nav
          className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-px sm:px-6"
          aria-label="Hojas del tablero"
        >
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={cn(
                "relative h-11 shrink-0 px-3 text-sm font-medium transition-colors duration-150",
                tab === item.id ? "text-fg" : "text-muted hover:text-fg",
              )}
            >
              {item.label}
              {tab === item.id ? (
                <span className="absolute inset-x-2 bottom-0 h-px bg-accent" />
              ) : null}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
        {tab === "resumen" ? (
          <Resumen
            onOpen={(id) => {
              setOpenId(id);
              setTab("eventos");
            }}
          />
        ) : null}
        {tab === "eventos" ? (
          <Eventos
            rows={filtered}
            sev={sev}
            est={est}
            onSev={setSev}
            onEst={setEst}
            openId={openId}
            onOpen={setOpenId}
          />
        ) : null}
        {tab === "cadena" ? (
          <Cadena
            onOpen={(id) => {
              setOpenId(id);
              setTab("eventos");
            }}
          />
        ) : null}
        {tab === "analisis" ? <Analisis /> : null}
        {tab === "glosario" ? <Glosario /> : null}
      </main>
    </div>
  );
}

function Resumen({ onOpen }: { onOpen: (id: string) => void }) {
  const tipoData = Object.entries(STATS.porTipo).map(([name, n]) => ({
    name:
      (
        {
          "Beaconing C2": "Beaconing C2",
          "Movimiento Lateral": "Pivote IT→OT",
          "Inyeccion de Paquetes ICS": "Inyección ICS",
          "Exfiltracion de Datos": "Exfiltración",
          "Despliegue de Malware": "Wiper HMI",
          "Intento de Modificacion": "Firmware PLC",
        } as Record<string, string>
      )[name] ?? name,
    n,
  }));
  const estadoData = [
    { name: "Exitoso", n: STATS.exitosos, fill: CHART.crit },
    { name: "Bloqueado", n: STATS.bloqueados, fill: CHART.ok },
    { name: "Investigando", n: STATS.investigando, fill: CHART.high },
  ];

  return (
    <div className="flex flex-col gap-6">
      <section className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-7 lg:gap-3">
        <Kpi label="Eventos" value={String(STATS.total)} hint="en 55 h 08 min" />
        <Kpi label="Críticos" value={String(STATS.criticos)} hint="tocan activos OT" tone="crit" />
        <Kpi label="Exitosos" value={String(STATS.exitosos)} hint="el acto ocurrió" tone="crit" />
        <Kpi label="Bloqueados" value={String(STATS.bloqueados)} hint="contenidos" tone="ok" />
        <Kpi label="Contención" value={`${STATS.contencion}%`} hint="3 de 7 detenidos" tone="high" />
        <Kpi label="Familias" value={String(STATS.hashes)} hint="hashes únicos" />
        <Kpi
          label="Segmentos"
          value={String(STATS.segmentos)}
          hint="IT 200.1.8–12/24"
          className="col-span-2 sm:col-span-1"
        />
      </section>

      <section className={cn(panel, "p-4 sm:p-5")}>
        <h2 className="text-sm font-medium text-muted">Lectura ejecutiva</h2>
        <p className="mt-2 max-w-4xl text-sm leading-relaxed text-fg">
          Entre el 1 oct 02:14 y el 3 oct 09:22 un actor explotó el EMS de Caracas, cruzó de IT a OT
          en cuatro minutos, inyectó DNP3 en una RTU, robó credenciales, borró la configuración de un
          HMI e intentó reflash de un PLC. Dos balizas C2 se bloquearon; el daño real está en OT
          (EVT-002, EVT-003, EVT-005). La familia FAM-PIVOTE sigue abierta. Las siete geolocalizaciones
          apuntan a {SITE.coords}.
        </p>
        <p className="mt-3 flex items-center gap-2 text-xs font-medium text-crit">
          <ShieldAlert className="size-4 shrink-0" />
          Riesgo residual: ALTO · OT comprometido · exfiltración sin cerrar
        </p>
      </section>

      <section className="grid gap-3 lg:grid-cols-2">
        <ChartCard title="Tipo de evento">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={tipoData} layout="vertical" margin={{ left: 8, right: 12, top: 4, bottom: 0 }}>
              <CartesianGrid stroke={CHART.grid} horizontal={false} />
              <XAxis
                type="number"
                allowDecimals={false}
                stroke={CHART.muted}
                tick={{ fill: CHART.muted, fontSize: 11 }}
              />
              <YAxis
                type="category"
                dataKey="name"
                width={96}
                stroke={CHART.muted}
                tick={{ fill: CHART.fg, fontSize: 11 }}
              />
              <Tooltip content={<ChartTip />} cursor={{ fill: CHART.surface }} />
              <Bar dataKey="n" radius={[0, 3, 3, 0]} fill={CHART.steel} barSize={12} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Estado">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={estadoData} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
              <CartesianGrid stroke={CHART.grid} vertical={false} />
              <XAxis dataKey="name" stroke={CHART.muted} tick={{ fill: CHART.fg, fontSize: 11 }} />
              <YAxis allowDecimals={false} stroke={CHART.muted} tick={{ fill: CHART.muted, fontSize: 11 }} />
              <Tooltip content={<ChartTip />} cursor={{ fill: CHART.surface }} />
              <Bar dataKey="n" radius={[3, 3, 0, 0]} barSize={28}>
                {estadoData.map((d) => (
                  <Cell key={d.name} fill={d.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-medium text-muted">Registro · toca una fila para el detalle</h2>
        <EventTable rows={INCIDENTS} openId={null} onOpen={onOpen} compact />
      </section>
    </div>
  );
}

function Eventos({
  rows,
  sev,
  est,
  onSev,
  onEst,
  openId,
  onOpen,
}: {
  rows: Incident[];
  sev: Severidad | "Todas";
  est: Estado | "Todos";
  onSev: (v: Severidad | "Todas") => void;
  onEst: (v: Estado | "Todos") => void;
  openId: string | null;
  onOpen: (id: string) => void;
}) {
  const selected = INCIDENTS.find((r) => r.id === openId) ?? rows[0] ?? null;
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-muted">
          {rows.length} de {INCIDENTS.length} eventos · filtros combinables
        </p>
        <div className="flex flex-wrap gap-2">
          <FilterGroup
            label="Severidad"
            value={sev}
            options={["Todas", "Critica", "Alta"]}
            onChange={(v) => onSev(v as Severidad | "Todas")}
          />
          <FilterGroup
            label="Estado"
            value={est}
            options={["Todos", "Exitoso", "Bloqueado", "Investigando"]}
            onChange={(v) => onEst(v as Estado | "Todos")}
          />
        </div>
      </div>
      <EventTable rows={rows} openId={openId} onOpen={onOpen} />
      {selected ? (
        <IncidentDetail row={selected} />
      ) : (
        <p className={cn(card, "px-4 py-6 text-sm text-muted")}>Ningún evento con esos filtros.</p>
      )}
    </div>
  );
}

function Cadena({ onOpen }: { onOpen: (id: string) => void }) {
  const deltas = [
    "+0 min",
    "+4 min",
    "+11 min",
    "+35 h 51 min",
    "+40 h 26 min",
    "+49 h 56 min",
    "+55 h 08 min",
  ];
  return (
    <div className="flex flex-col gap-6">
      <section className={cn(panel, "p-4 sm:p-5")}>
        <h2 className="text-sm font-medium text-muted">IT → OT en once minutos</h2>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-fg">
          La primera baliza se bloquea. Cuatro minutos después el pivote ya está en el LAN OT. Siete
          minutos más y hay DNP3 en una RTU. El resto de la campaña (exfil, wiper, reflash) ocurre en
          las 55 horas siguientes con las mismas tres familias de hash.
        </p>
      </section>
      <ol className="flex flex-col gap-2">
        {INCIDENTS.map((row, i) => (
          <li key={row.id}>
            <button
              type="button"
              onClick={() => onOpen(row.id)}
              className="flex w-full flex-col gap-2 rounded-lg border border-border bg-surface px-4 py-3 text-left transition-colors duration-150 hover:bg-surface-2 sm:flex-row sm:items-center sm:gap-4"
            >
              <span className="font-mono text-xs text-muted tabular-nums sm:w-28">{deltas[i]}</span>
              <span className="font-mono text-xs text-subtle sm:w-16">{row.id}</span>
              <span className="flex-1 text-sm font-medium text-fg">{row.tipoEvento}</span>
              <span className="font-mono text-xs text-muted">
                {row.ipOrigen} → {row.destinoLabel}
              </span>
              <EstadoBadge estado={row.estado} />
            </button>
          </li>
        ))}
      </ol>
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted">Arquitectura tocada</h2>
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full text-left text-sm">
            <thead className="bg-surface-2 text-xs tracking-wide text-muted uppercase">
              <tr>
                <th className="px-3 py-2.5 font-medium">Zona</th>
                <th className="px-3 py-2.5 font-medium">Host</th>
                <th className="px-3 py-2.5 font-medium">Rol</th>
                <th className="px-3 py-2.5 font-medium">Resultado</th>
              </tr>
            </thead>
            <tbody className="bg-surface">
              {[
                ["IT EMS", "200.1.8.0/24", "Energy Management", "C2 bloqueado; host infectado"],
                ["OT LAN", "10.0.50.5", "Backbone de control", "Pivote exitoso — aislar"],
                ["OT campo", "10.0.50.12", "RTU", "DNP3 inyectado — auditar"],
                ["OT campo", "10.0.50.15", "PLC", "Firmware bloqueado — verificar hash"],
                ["OT supervisión", "10.0.60.2", "HMI", "Config borrada — reinstalar"],
                ["C2", "198.51.100.22 / .44", "Beacon + exfil", "Sinkhole y bloqueo"],
              ].map((r) => (
                <tr key={r[1]} className="border-t border-border">
                  <td className="px-3 py-2.5 text-fg">{r[0]}</td>
                  <td className="px-3 py-2.5 font-mono text-xs text-muted">{r[1]}</td>
                  <td className="px-3 py-2.5 text-muted">{r[2]}</td>
                  <td className="px-3 py-2.5 text-fg">{r[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Analisis() {
  return (
    <div className="flex flex-col gap-6">
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted">Tres familias de hash</h2>
        <div className="grid gap-3 md:grid-cols-3">
          {FAMILIAS.map((f) => (
            <article key={f.id} className={cn(card, "p-4")}>
              <p className="font-mono text-xs text-subtle">{f.id}</p>
              <p className="mt-1 font-mono text-xs text-muted">{f.hash}</p>
              <p className="mt-3 text-sm text-fg">{f.rol}</p>
              <p className="mt-2 text-xs text-muted">{f.eventos.join(" · ")}</p>
              <p className="mt-3 text-xs font-medium text-accent">{f.estado}</p>
            </article>
          ))}
        </div>
      </section>
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted">Plan de respuesta</h2>
        <ul className="flex flex-col gap-2">
          {RECOMENDACIONES.map((r) => (
            <li key={r.titulo} className={cn(card, "flex flex-col gap-1 px-4 py-3 sm:flex-row sm:gap-4")}>
              <span
                className={cn(
                  "font-mono text-xs font-medium sm:w-8",
                  r.prioridad === "P0" ? "text-crit" : r.prioridad === "P1" ? "text-high" : "text-info",
                )}
              >
                {r.prioridad}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-medium text-fg">{r.titulo}</p>
                <p className="mt-1 text-sm text-muted">{r.detalle}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function Glosario() {
  return (
    <div className="flex flex-col gap-2">
      <p className="mb-2 text-sm text-muted">Cómo leer cada columna del Excel y los acrónimos de planta.</p>
      {GLOSARIO.map((g) => (
        <div
          key={g.termino}
          className="grid gap-1 rounded-md border border-border bg-surface px-4 py-3 sm:grid-cols-[14rem_1fr] sm:gap-4"
        >
          <p className="font-mono text-sm text-accent">{g.termino}</p>
          <p className="text-sm leading-relaxed text-fg">{g.significado}</p>
        </div>
      ))}
    </div>
  );
}

function Kpi({
  label,
  value,
  hint,
  tone,
  className,
}: {
  label: string;
  value: string;
  hint: string;
  tone?: "crit" | "ok" | "high";
  className?: string;
}) {
  return (
    <article className={cn(card, "px-3 py-3 sm:px-4", className)}>
      <p className="text-xs font-medium tracking-widest text-muted uppercase">{label}</p>
      <p
        className={cn(
          "mt-1 font-mono text-2xl font-medium tabular-nums",
          tone === "crit" ? "text-crit" : tone === "ok" ? "text-ok" : tone === "high" ? "text-high" : "text-fg",
        )}
      >
        {value}
      </p>
      <p className="mt-1 text-xs text-subtle">{hint}</p>
    </article>
  );
}

function ChartCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <article className={cn(panel, "p-4 sm:p-5")}>
      <h2 className="mb-3 text-sm font-medium text-muted">{title}</h2>
      {children}
    </article>
  );
}

function ChartTip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-sm border border-border bg-surface-2 px-2 py-1 text-xs text-fg">
      {label}: {payload[0]?.value}
    </div>
  );
}

function FilterGroup({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-1 rounded-sm border border-border bg-surface p-1">
      <span className="sr-only">{label}</span>
      {options.map((opt) => (
        <button
          key={opt}
          type="button"
          onClick={() => onChange(opt)}
          className={cn(
            "h-9 rounded-xs px-3 text-xs font-medium transition-colors duration-150",
            value === opt ? "bg-surface-2 text-fg" : "text-muted hover:text-fg",
          )}
        >
          {opt}
        </button>
      ))}
    </div>
  );
}

function EventTable({
  rows,
  openId,
  onOpen,
  compact,
}: {
  rows: Incident[];
  openId: string | null;
  onOpen: (id: string) => void;
  compact?: boolean;
}) {
  return (
    <div className="overflow-x-auto rounded-lg border border-border">
      <table className="w-full text-left text-sm">
        <thead className="bg-surface-2 text-xs tracking-wide text-muted uppercase">
          <tr>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">ID</th>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">Fecha_Hora</th>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">IP_Origen</th>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">IP_Destino</th>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">Tipo_Evento</th>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">Severidad</th>
            <th className="px-3 py-2.5 font-medium whitespace-nowrap">Estado</th>
            {compact ? null : <th className="px-3 py-2.5 font-medium whitespace-nowrap">Metodo_Ataque</th>}
          </tr>
        </thead>
        <tbody className="bg-surface">
          {rows.map((row) => (
            <tr
              key={row.id}
              onClick={() => onOpen(row.id)}
              className={cn(
                "cursor-pointer border-t border-border transition-colors duration-150 hover:bg-surface-2",
                openId === row.id && "bg-surface-2",
              )}
            >
              <td className="px-3 py-2.5 font-mono text-xs text-subtle">{row.id}</td>
              <td className="px-3 py-2.5 font-mono text-xs tabular-nums">{row.fechaHora}</td>
              <td className="px-3 py-2.5 font-mono text-xs">{row.ipOrigen}</td>
              <td className="px-3 py-2.5 font-mono text-xs">
                {row.ipDestino}
                <span className="ml-1 text-subtle"> {row.destinoLabel}</span>
              </td>
              <td className="px-3 py-2.5">{row.tipoEvento}</td>
              <td className="px-3 py-2.5">
                <SevBadge severidad={row.severidad} />
              </td>
              <td className="px-3 py-2.5">
                <EstadoBadge estado={row.estado} />
              </td>
              {compact ? null : <td className="px-3 py-2.5 text-muted">{row.metodoAtaque}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function IncidentDetail({ row }: { row: Incident }) {
  return (
    <article className={cn(panel, "grid gap-4 p-4 sm:p-5 lg:grid-cols-3")}>
      <div className="lg:col-span-2">
        <div className="flex flex-wrap items-center gap-2">
          <p className="font-mono text-xs text-subtle">{row.id}</p>
          <SevBadge severidad={row.severidad} />
          <EstadoBadge estado={row.estado} />
        </div>
        <h3 className="mt-2 text-lg font-medium text-fg">{row.tipoEvento}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted">{row.impacto}</p>
      </div>
      <dl className="grid grid-cols-2 gap-x-3 gap-y-2 text-sm">
        <Item k="Fecha_Hora" v={row.fechaHora} mono />
        <Item k="Fase" v={row.fase} />
        <Item k="IP_Origen" v={row.ipOrigen} mono />
        <Item k="Segmento" v={row.segmento} mono />
        <Item k="IP_Destino" v={`${row.ipDestino} (${row.destinoLabel})`} mono />
        <Item k="Coordenadas" v={row.coordenadas} />
        <Item k="Metodo_Ataque" v={row.metodoAtaque} />
        <Item k="MITRE" v={row.mitre} mono />
        <Item k="Hash_Asociado" v={row.hash} mono />
        <Item k="Familia" v={row.hashFamilia} mono />
      </dl>
    </article>
  );
}

function Item({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div>
      <dt className="text-xs tracking-wide text-subtle uppercase">{k}</dt>
      <dd className={cn("mt-0.5 text-fg", mono && "font-mono text-xs")}>{v}</dd>
    </div>
  );
}

function SevBadge({ severidad }: { severidad: Severidad }) {
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center rounded-xs px-2 text-xs font-medium tracking-wide uppercase",
        severidad === "Critica" ? "bg-crit/15 text-crit" : "bg-high/15 text-high",
      )}
    >
      {severidad}
    </span>
  );
}

function EstadoBadge({ estado }: { estado: Estado }) {
  const Icon = estado === "Bloqueado" ? ShieldCheck : estado === "Exitoso" ? ShieldAlert : Radio;
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center gap-1 rounded-xs px-2 text-xs font-medium tracking-wide uppercase",
        estado === "Bloqueado"
          ? "bg-ok/15 text-ok"
          : estado === "Exitoso"
            ? "bg-crit/15 text-crit"
            : "bg-high/15 text-high",
      )}
    >
      <Icon className="size-3" />
      {estado}
    </span>
  );
}
