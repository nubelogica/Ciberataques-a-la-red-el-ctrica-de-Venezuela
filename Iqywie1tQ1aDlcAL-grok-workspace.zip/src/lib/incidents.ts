export type Severidad = "Critica" | "Alta";
export type Estado = "Bloqueado" | "Exitoso" | "Investigando";

export type Incident = {
  id: string;
  fechaHora: string;
  ts: number;
  ipOrigen: string;
  segmento: string;
  ipDestino: string;
  destinoLabel: string;
  zonaDestino: "IT" | "OT" | "C2";
  tipoEvento: string;
  lat: number;
  lon: number;
  ciudad: string;
  coordenadas: string;
  severidad: Severidad;
  metodoAtaque: string;
  hash: string;
  hashFamilia: string;
  estado: Estado;
  fase: string;
  mitre: string;
  impacto: string;
};

export const SITE = {
  name: "GRIDWATCH",
  org: "Corpoelec · Electricidad de Caracas",
  zona: "Caracas, VE",
  coords: "10.4806, -66.9036",
  ventana: "1–3 octubre 2026",
  clasificacion: "CONFIDENCIAL · Uso interno SOC/OT",
} as const;

export const INCIDENTS: Incident[] = [
  {
    id: "EVT-001",
    fechaHora: "2026-10-01 02:14:00",
    ts: Date.parse("2026-10-01T02:14:00-04:00"),
    ipOrigen: "200.1.8.45",
    segmento: "200.1.8.0/24",
    ipDestino: "198.51.100.22",
    destinoLabel: "C2 externo",
    zonaDestino: "C2",
    tipoEvento: "Beaconing C2",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Alta",
    metodoAtaque: "Explotacion EMS",
    hash: "365ede59ae5b9332b9fb...",
    hashFamilia: "FAM-EMS-C2",
    estado: "Bloqueado",
    fase: "1. Comando y control",
    mitre: "ICS T0885 / T0869",
    impacto: "Baliza C2 bloqueada en el perímetro. No hubo sesión establecida.",
  },
  {
    id: "EVT-002",
    fechaHora: "2026-10-01 02:18:12",
    ts: Date.parse("2026-10-01T02:18:12-04:00"),
    ipOrigen: "200.1.9.112",
    segmento: "200.1.9.0/24",
    ipDestino: "10.0.50.5",
    destinoLabel: "OT LAN",
    zonaDestino: "OT",
    tipoEvento: "Movimiento Lateral",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Critica",
    metodoAtaque: "Pivote IT a OT",
    hash: "77f2209a3a35b879ffdd...",
    hashFamilia: "FAM-PIVOTE",
    estado: "Exitoso",
    fase: "2. Cruce de air-gap lógico",
    mitre: "ICS T0866 / T0886",
    impacto: "El atacante cruzó de la red IT al LAN OT. Punto de no retorno operativo.",
  },
  {
    id: "EVT-003",
    fechaHora: "2026-10-01 02:25:30",
    ts: Date.parse("2026-10-01T02:25:30-04:00"),
    ipOrigen: "200.1.10.14",
    segmento: "200.1.10.0/24",
    ipDestino: "10.0.50.12",
    destinoLabel: "RTU",
    zonaDestino: "OT",
    tipoEvento: "Inyeccion de Paquetes ICS",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Critica",
    metodoAtaque: "Manipulacion Protocolo DNP3",
    hash: "65b928be07f528ded928...",
    hashFamilia: "FAM-ICS-PAYLOAD",
    estado: "Exitoso",
    fase: "3. Manipulación de control",
    mitre: "ICS T0831 / T0836",
    impacto: "Paquetes DNP3 inyectados a una RTU. Posible alteración de telemetría o consigna.",
  },
  {
    id: "EVT-004",
    fechaHora: "2026-10-02 14:05:22",
    ts: Date.parse("2026-10-02T14:05:22-04:00"),
    ipOrigen: "200.1.11.250",
    segmento: "200.1.11.0/24",
    ipDestino: "198.51.100.44",
    destinoLabel: "Exfil C2",
    zonaDestino: "C2",
    tipoEvento: "Exfiltracion de Datos",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Alta",
    metodoAtaque: "Robo de Credenciales",
    hash: "77f2209a3a35b879ffdd...",
    hashFamilia: "FAM-PIVOTE",
    estado: "Investigando",
    fase: "4. Exfiltración",
    mitre: "ICS T0893 / T0882",
    impacto: "Salida de datos hacia 198.51.100.44. Alcance de lo robado aún no cerrado.",
  },
  {
    id: "EVT-005",
    fechaHora: "2026-10-02 18:40:00",
    ts: Date.parse("2026-10-02T18:40:00-04:00"),
    ipOrigen: "200.1.12.8",
    segmento: "200.1.12.0/24",
    ipDestino: "10.0.60.2",
    destinoLabel: "HMI",
    zonaDestino: "OT",
    tipoEvento: "Despliegue de Malware",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Critica",
    metodoAtaque: "Wiper (Borrado de Configuración)",
    hash: "65b928be07f528ded928...",
    hashFamilia: "FAM-ICS-PAYLOAD",
    estado: "Exitoso",
    fase: "5. Impacto / destrucción",
    mitre: "ICS T0826 / T0872",
    impacto: "Wiper en HMI. Pérdida de configuración de supervisión. Recuperar desde backup limpio.",
  },
  {
    id: "EVT-006",
    fechaHora: "2026-10-03 04:10:15",
    ts: Date.parse("2026-10-03T04:10:15-04:00"),
    ipOrigen: "200.1.8.201",
    segmento: "200.1.8.0/24",
    ipDestino: "198.51.100.22",
    destinoLabel: "C2 externo",
    zonaDestino: "C2",
    tipoEvento: "Beaconing C2",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Alta",
    metodoAtaque: "Explotacion EMS",
    hash: "365ede59ae5b9332b9fb...",
    hashFamilia: "FAM-EMS-C2",
    estado: "Bloqueado",
    fase: "1. Comando y control",
    mitre: "ICS T0885 / T0869",
    impacto: "Segunda baliza al mismo C2, bloqueada. El actor reintenta el canal EMS.",
  },
  {
    id: "EVT-007",
    fechaHora: "2026-10-03 09:22:45",
    ts: Date.parse("2026-10-03T09:22:45-04:00"),
    ipOrigen: "200.1.11.55",
    segmento: "200.1.11.0/24",
    ipDestino: "10.0.50.15",
    destinoLabel: "PLC",
    zonaDestino: "OT",
    tipoEvento: "Intento de Modificacion",
    lat: 10.4806,
    lon: -66.9036,
    ciudad: "Caracas",
    coordenadas: "10.4806,-66.9036 (Caracas)",
    severidad: "Critica",
    metodoAtaque: "Sobrescritura de Firmware",
    hash: "65b928be07f528ded928...",
    hashFamilia: "FAM-ICS-PAYLOAD",
    estado: "Bloqueado",
    fase: "6. Persistencia en campo",
    mitre: "ICS T0857",
    impacto: "Intento de reflash de PLC detenido. Si hubiera pasado, el control quedaba en manos del actor.",
  },
];

export const FAMILIAS = [
  {
    id: "FAM-EMS-C2",
    hash: "365ede59ae5b9332b9fb...",
    rol: "Canal C2 vía EMS",
    eventos: ["EVT-001", "EVT-006"],
    estado: "Contenida",
  },
  {
    id: "FAM-PIVOTE",
    hash: "77f2209a3a35b879ffdd...",
    rol: "Pivote IT→OT y robo de credenciales",
    eventos: ["EVT-002", "EVT-004"],
    estado: "Activa / en investigación",
  },
  {
    id: "FAM-ICS-PAYLOAD",
    hash: "65b928be07f528ded928...",
    rol: "Payload ICS (DNP3, wiper, firmware)",
    eventos: ["EVT-003", "EVT-005", "EVT-007"],
    estado: "Parcialmente contenida",
  },
] as const;

export const GLOSARIO = [
  {
    termino: "Fecha_Hora",
    significado: "Marca temporal local de Caracas (UTC−4) en que se observó el evento.",
  },
  {
    termino: "IP_Origen",
    significado: "Host que inició la acción. Rangos 200.1.x.x = red IT de distribución Caracas.",
  },
  {
    termino: "Segmento",
    significado: "Subred /24 del origen. Sirve para aislar o poner en cuarentena un anillo completo.",
  },
  {
    termino: "IP_Destino",
    significado: "Objetivo de la conexión. 10.0.50.x/10.0.60.x = OT; 198.51.100.x = infraestructura C2.",
  },
  {
    termino: "Tipo_Evento",
    significado: "Qué se vio: baliza C2, cruce lateral, inyección ICS, exfil, malware o cambio de firmware.",
  },
  {
    termino: "Coordenadas_Aprox",
    significado: "Geolocalización aproximada del origen (Caracas 10.4806, −66.9036).",
  },
  {
    termino: "Severidad",
    significado: "Alta = compromiso IT/C2. Crítica = toca activos de control (RTU, PLC, HMI, LAN OT).",
  },
  {
    termino: "Metodo_Ataque",
    significado: "Técnica usada. EMS, DNP3, wiper y firmware son las más graves en un sistema eléctrico.",
  },
  {
    termino: "Hash_Asociado",
    significado: "Huella del artefacto. El mismo hash en varios eventos = misma familia de malware.",
  },
  {
    termino: "Estado",
    significado: "Bloqueado = control de seguridad detuvo el acto. Exitoso = el acto ocurrió. Investigando = aún abierto.",
  },
  {
    termino: "EMS",
    significado: "Energy Management System: software que supervisa y despacha la red eléctrica.",
  },
  {
    termino: "RTU",
    significado: "Remote Terminal Unit: equipo de campo que lee sensores y ejecuta órdenes en subestaciones.",
  },
  {
    termino: "PLC",
    significado: "Programmable Logic Controller: controlador de proceso. Un firmware malicioso lo deja capturado.",
  },
  {
    termino: "HMI",
    significado: "Human-Machine Interface: pantalla de operación. Un wiper borra la configuración de supervisión.",
  },
  {
    termino: "DNP3",
    significado: "Protocolo estándar de telecontrol eléctrico. Paquetes inyectados pueden falsear medidas o mandos.",
  },
  {
    termino: "Beaconing C2",
    significado: "El host infectado llama a un servidor de comando y control para pedir órdenes.",
  },
  {
    termino: "Wiper",
    significado: "Malware que borra, no espía. Aquí apuntó a la configuración del HMI.",
  },
] as const;

export const RECOMENDACIONES = [
  {
    prioridad: "P0",
    titulo: "Aislar LAN OT 10.0.50.0/24 y HMI 10.0.60.2",
    detalle:
      "EVT-002 y EVT-003 cruzaron a OT y tocaron una RTU. Sacar de producción, modo manual seguro, no reconectar a IT.",
  },
  {
    prioridad: "P0",
    titulo: "Reinstalar HMI desde imagen limpia",
    detalle:
      "EVT-005 (wiper) fue exitoso. No confiar en la config actual. Restaurar backup verificado anterior al 1 oct.",
  },
  {
    prioridad: "P0",
    titulo: "Verificar firmware de PLC 10.0.50.15 y RTU 10.0.50.12",
    detalle:
      "El reflash se bloqueó, la inyección DNP3 no. Comparar hashes de firmware y lógica contra el gold image.",
  },
  {
    prioridad: "P1",
    titulo: "Cortar 198.51.100.22 y 198.51.100.44",
    detalle:
      "C2 y exfil. Bloqueo perimetral + DNS sinkhole. Buscar más balizas al mismo /24.",
  },
  {
    prioridad: "P1",
    titulo: "Rotar credenciales del EMS y cuentas de ingeniería",
    detalle:
      "EVT-004 indica robo de credenciales (familia FAM-PIVOTE). Invalidar tokens, VPN y cuentas de servicio.",
  },
  {
    prioridad: "P1",
    titulo: "Cuarentena de segmentos 200.1.8–12.0/24",
    detalle:
      "Todos los orígenes salen de esos /24 IT. Forense en 200.1.9.112 (pivote) y 200.1.12.8 (wiper).",
  },
  {
    prioridad: "P2",
    titulo: "Cazar las 3 familias de hash",
    detalle:
      "EMS-C2 contenida; PIVOTE activa; ICS-PAYLOAD parcialmente contenida. EDR/YARA en IT y allow-list en OT.",
  },
];

function countBy<T extends string>(rows: Incident[], key: (r: Incident) => T): Record<T, number> {
  const out = {} as Record<T, number>;
  for (const row of rows) {
    const k = key(row);
    out[k] = (out[k] ?? 0) + 1;
  }
  return out;
}

export function buildStats(rows: Incident[] = INCIDENTS) {
  const total = rows.length;
  const porSeveridad = countBy(rows, (r) => r.severidad);
  const porEstado = countBy(rows, (r) => r.estado);
  const porTipo = countBy(rows, (r) => r.tipoEvento);
  const porMetodo = countBy(rows, (r) => r.metodoAtaque);
  const porZona = countBy(rows, (r) => r.zonaDestino);
  const criticos = porSeveridad.Critica ?? 0;
  const altas = porSeveridad.Alta ?? 0;
  const bloqueados = porEstado.Bloqueado ?? 0;
  const exitosos = porEstado.Exitoso ?? 0;
  const investigando = porEstado.Investigando ?? 0;
  const contencion = total ? Math.round((bloqueados / total) * 100) : 0;
  const hashes = new Set(rows.map((r) => r.hash)).size;
  const segmentos = new Set(rows.map((r) => r.segmento)).size;
  const otComprometido = rows.some(
    (r) => r.zonaDestino === "OT" && r.estado === "Exitoso",
  );
  const first = rows[0];
  const last = rows[rows.length - 1];
  const ventanaHoras =
    first && last ? (last.ts - first.ts) / 3_600_000 : 0;

  return {
    total,
    criticos,
    altas,
    bloqueados,
    exitosos,
    investigando,
    contencion,
    hashes,
    segmentos,
    otComprometido,
    ventanaHoras,
    porSeveridad,
    porEstado,
    porTipo,
    porMetodo,
    porZona,
  };
}

export const STATS = buildStats();

export const CHART = {
  fg: "#e8edf2",
  muted: "#8b98a5",
  grid: "#2a343e",
  crit: "#e11d48",
  high: "#d97706",
  ok: "#0f9d7a",
  info: "#5b8fb3",
  steel: "#c5ccd4",
  surface: "#1b232c",
} as const;
