import { createFileRoute } from "@tanstack/react-router";
import { SocDashboard } from "@/components/soc-dashboard";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SocDashboard />;
}
